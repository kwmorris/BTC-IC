/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>

int
blank_slate (void)
{

  int n, m;

  step = 0;
  cost = 0;
  par_steps = 0;
  par_cost = 0;
  par_time = 0;
  limit_steps = 0;
  limit_cost = 0;
  limit_time = 0;
  fault = 0;
  conclusion = -1;		// -1 means no choice has been made yet ; 0 means user has chosen "no faults"
  mistake = 0;
  noise = 0.00;

  for (n = 0; n < COUNT; ++n)
    {
      // Initializing test point currents
      i_tp[n] = 0;

      // Initializing test point voltages
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = 0;

      // Initializing voltmeter and ammeter test lead positions
      vm_red = 0;		// Voltmeter red lead on test point 0
      vm_black = 0;		// Voltmeter black lead on test point 0 
      am_tp = 0;		// Ammeter on test point 0 (nothing)

      // Initializing text descriptions of each fault
      faults[n] = NULL;

      // Initializing log of diagnostic steps taken by user
      steplog[n].code = ' ';
      steplog[n].d = NULL;
      steplog[n].vm = 0.0;
      steplog[n].am = 0.0;
      steplog[n].adjust = 0.0;
      steplog[n].vtp[0] = 0;
      steplog[n].vtp[1] = 0;
      steplog[n].atp = 0;
      steplog[n].num = 0;
      steplog[n].cost = 0;
      steplog[n].time = 0;
      steplog[n].r = NULL;

      // Initializing DC voltage sources
      dcv[n].h = 0;		// All source statuses are healthy (0)
      dcv[n].alt[0] = 3.0;	// First nominal voltage value (Volts)
      dcv[n].alt[1] = 5.0;
      dcv[n].alt[2] = 6.0;
      dcv[n].alt[3] = 9.0;
      dcv[n].alt[4] = 10.0;
      dcv[n].alt[5] = 12.0;
      dcv[n].alt[6] = 15.0;
      dcv[n].alt[7] = 18.0;
      dcv[n].alt[8] = 24.0;
      dcv[n].alt[9] = 28.0;
      dcv[n].selected = dcv[n].alt[0];	// Set selected nominal voltage to first value
      dcv[n].r[0] = dcv[n].selected / 30.0;	// Internal series resistance assuming 30 Amperes max I
      dcv[n].r[1] = 9e8;	// Internal series resistance assuming dead source with open fault
      dcv[n].r[2] = 1e-1;	// Internal series resistance assuming dead source with shorted fault
      dcv[n].tolerance = 1.0;	// +/- 1% voltage tolerance from nominal value
//      dcv[n].tolerance = 0.0; // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR PERFECT SOURCES!
      dcv[n].v[0] = random_component (dcv[n].selected, dcv[n].tolerance);	// Set actual voltage to selected value
      dcv[n].v[1] = 0.0;	// Dead source voltage with open fault
      dcv[n].v[2] = 0.0;	// Dead source voltage with shorted fault

      // Initializing DC current sources
      dci[n].h = 0;		// All source statuses are healthy (0)
      dci[n].alt[0] = 3e-3;	// First nominal current value (Amperes)
      dci[n].alt[1] = 4e-3;
      dci[n].alt[2] = 5e-3;
      dci[n].alt[3] = 6e-3;
      dci[n].alt[4] = 7e-3;
      dci[n].alt[5] = 8e-3;
      dci[n].alt[6] = 9e-3;
      dci[n].alt[7] = 10e-3;
      dci[n].alt[8] = 12e-3;
      dci[n].alt[9] = 15e-3;
      dci[n].selected = dci[n].alt[0];	// Set selected nominal current to first value
      dci[n].r[0] = 30.0 / dci[n].selected;	// Internal parallel resistance assuming 30 Volts max V
      dci[n].r[1] = 9e8;	// Internal parallel resistance assuming dead source with open fault
      dci[n].r[2] = 1e-1;	// Internal parallel resistance assuming dead source with shorted fault
      dci[n].tolerance = 1.0;	// +/- 1% current tolerance from nominal value
//      dci[n].tolerance = 0.0; // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR PERFECT SOURCES!
      dci[n].i[0] = random_component (dci[n].selected, dci[n].tolerance);	// Set actual current to selected value with tolerance
      dci[n].i[1] = 1e-12;	// Dead source current with open fault
      dci[n].i[2] = 1e-10;	// Dead source current with shorted fault

      // Initializing resistors
      r[n].h = 0;		// All resistor statuses are healthy (0)
      r[n].alt[0] = 930.0;	// First nominal resistance value (Ohms)
      r[n].alt[1] = 1000.0;
      r[n].alt[2] = 1500.0;
      r[n].alt[3] = 3300.0;
      r[n].alt[4] = 4700.0;
      r[n].alt[5] = 5100.0;
      r[n].alt[6] = 6300.0;
      r[n].alt[7] = 7100.0;
      r[n].alt[8] = 10000.0;
      r[n].alt[9] = 12000.0;
      r[n].selected = r[n].alt[0];	// Set selected nominal resistance to first value
      r[n].tolerance = 5.0;	// +/- 5% resistance tolerance from nominal value
//      r[n].tolerance = 0.0;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR PERFECT RESISTORS!
      r[n].r[0] = random_component (r[n].selected, r[n].tolerance);	// Set actual resistance to selected value with tolerance
      r[n].r[1] = 9e8;		// Actual resistance assuming open fault
      r[n].r[2] = 1e-2;		// Actual resistance assuming shorted fault

      // Initializing potentiometers
      pot[n].h = 0;		// All potentiometer statuses are healthy (0)
      pot[n].x = 0.5;		// Set wiper to the 50% position
      pot[n].alt[0] = 100.0;	// First nominal resistance value (Ohms)
      pot[n].alt[1] = 500.0;
      pot[n].alt[2] = 1000.0;
      pot[n].alt[3] = 1500.0;
      pot[n].alt[4] = 2000.0;
      pot[n].alt[5] = 3000.0;
      pot[n].alt[6] = 5000.0;
      pot[n].alt[7] = 7000.0;
      pot[n].alt[8] = 10000.0;
      pot[n].alt[9] = 20000.0;
      pot[n].selected = pot[n].alt[2];	// Set selected nominal resistance to third value (1k Ohms)
      pot[n].tolerance = 5.0;	// +/- 5% resistance tolerance from nominal value
//      pot[n].tolerance = 0.0;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR PERFECT POTENTIOMETERS!
      pot[n].r_total = random_component (pot[n].selected, pot[n].tolerance);	// Set actual resistance to selected value with tolerance
      pot[n].r0[0] = pot[n].r_total * pot[n].x;	// Actual resistance from wiper to 0% terminal
      pot[n].r100[0] = pot[n].r_total * (1.0 - pot[n].x);	// Actual resistance from wiper to 100% terminal
      pot[n].r0[1] = 9e8;	// Wiper-0% terminal resistance assuming open 0% terminal fault
      pot[n].r0[2] = pot[n].r0[0];	// Wiper-0% terminal resistance assuming open 100% terminal fault
      pot[n].r0[3] = pot[n].r0[0];	// Wiper-0% terminal resistance assuming open wiper fault
      pot[n].r100[1] = pot[n].r100[0];	// Wiper-100% terminal resistance assuming open 0% terminal fault
      pot[n].r100[2] = 9e8;	// Wiper-100% terminal resistance assuming open 100% terminal fault
      pot[n].r100[3] = pot[n].r100[0];	// Wiper-100% terminal resistance assuming open wiper fault
      pot[n].r_wiper[0] = 1e-2;	// Wiper-track healthy resistance
      pot[n].r_wiper[1] = 1e-2;	// Wiper-track resistance assuming open 0% terminal fault
      pot[n].r_wiper[2] = 1e-2;	// Wiper-track resistance assuming open 100% terminal fault
      pot[n].r_wiper[3] = 9e8;	// Wiper-track resistance assuming open wiper fault

      // Initializing fuses
      f[n].h = 0;		// All fuse statuses are healthy (0)
      f[n].r[0] = 1e-1;		// End-to-end resistance assuming healthy status
      f[n].r[1] = 9e9;		// End-to-end resistance assuming blown (open) status
      f[n].imax = 1;		// Maximum current set to 1 Ampere

      // Initializing toggle switches
      s[n].s = 0;		// All toggle switch states are open (0)
      s[n].h = 0;		// All toggle switch statuses are healthy (0)
      s[n].r[0][0] = 9e8;	// Contact resistance with switch open, healthy status
      s[n].r[1][0] = 1e-2;	// Contact resistance with switch closed, healthy status
      s[n].r[0][1] = 9e8;	// Contact resistance with switch open, failed open
      s[n].r[1][1] = 9e8;	// Contact resistance with switch closed, failed open
      s[n].r[0][2] = 1e-1;	// Contact resistance with switch open, failed shorted
      s[n].r[1][2] = 1e-1;	// Contact resistance with switch closed, failed shorted

      // Initializing relay contacts
      rc[n].s = 0;		// All relay contact states are open (0)
      rc[n].h = 0;		// All relay contact statuses are healthy (0)
      rc[n].r[0][0] = 9e8;	// Contact resistance with open state, healthy status
      rc[n].r[1][0] = 1e-2;	// Contact resistance with closed state, healthy status
      rc[n].r[0][1] = 9e8;	// Contact resistance with open state, contact failed open
      rc[n].r[1][1] = 9e8;	// Contact resistance with closed state, contact failed open
      rc[n].r[0][2] = 1e-1;	// Contact resistance with open state, contact failed shorted
      rc[n].r[1][2] = 1e-1;	// Contact resistance with closed state, contact failed shorted

      // Initializing permanent wires
      w[n].h = 0;		// All permanent wire statuses are healthy (0)
      w[n].r[0] = 1.0;		// End-to-end resistance assuming healthy status
      w[n].r[1] = 9e8;		// End-to-end resistance assuming open 

      // Initializing jumper wires
      j[n].s = 0;		// All jumper wires are uninstalled (0)
      j[n].r[0] = 9e9;		// End-to-end resistance assuming uninstalled
      j[n].r[1] = 1e-1;		// End-to-end resistance assuming connected 
      j[n].jtp[0] = 0;		// Jumper test point set to 0 by default
      j[n].jtp[1] = 0;		// Jumper test point set to 0 by default

      // Initializing generic loads
      ld[n].s = 0;		// All loads are de-energized (0)
      ld[n].h = 0;		// All loads are healthy (0)
      ld[n].d = "Generic load";	// All loads are named "Generic load"
      ld[n].r[0] = 1000.0;	// Load resistance when healthy
      ld[n].r[1] = 9e8;		// Load resistance assuming open fault
      ld[n].r[2] = 1e-1;	// Load resistance assuming shorted fault
      ld[n].v = 0.0;		// Terminal voltages set to zero
      ld[n].i = 0.0;		// Terminal currents set to zero
      ld[n].v_min = 12.0;	// Minimum voltage for energization
      ld[n].i_min = 12.0;	// Minimum current for energization

      // Initializing capacitors
      c[n].h = 0;		// All capacitor statuses are healthy (0)
      c[n].alt[0] = 1e-6;	// First nominal capacitance value (Farads)
      c[n].alt[1] = 2.2e-6;
      c[n].alt[2] = 3.3e-6;
      c[n].alt[3] = 4.7e-6;
      c[n].alt[4] = 10e-6;
      c[n].alt[5] = 33e-6;
      c[n].alt[6] = 100e-6;
      c[n].alt[7] = 2200e-6;
      c[n].alt[8] = 4700e-6;
      c[n].alt[9] = 10000e-6;
      c[n].selected = c[n].alt[0];	// Set selected nominal capacitance to first value
      c[n].tolerance = 15.0;	// +/- 15% capacitance tolerance from nominal value
      c[n].c = random_component (c[n].selected, c[n].tolerance);	// Set actual capacitance to selected value with tolerance
      c[n].esr[0] = 1;		// Set Equivalent Series Resistance value when healthy
      c[n].esr[1] = 9e8;	// Set Equivalent Series Resistance value when failed open
      c[n].esr[2] = 1e-2;	// Set Equivalent Series Resistance value when failed shorted
      c[n].epr[0] = 9e5;	// Set Equivalent Parallel Resistance value when healthy
      c[n].epr[1] = 9e8;	// Set Equivalent Parallel Resistance value when failed open
      c[n].epr[2] = 1e-2;	// Set Equivalent Parallel Resistance value when failed shorted
    }


  /*

     // Printf statements included only for testing purposes during development!!!
     printf ("DC voltage source #1 voltage = %f Volts \n", dcv[1].v);
     printf ("   internal resistance = %f Ohms \n", dcv[1].r[0]);
     printf ("   internal resistance (open) = %f Ohms \n", dcv[1].r[1]);
     printf ("   internal resistance (shorted) = %f Ohms \n", dcv[1].r[2]);

     printf ("DC current source #1 current = %f Amperes \n", dci[1].i);
     printf ("   internal resistance = %f Ohms \n", dci[1].r[0]);
     printf ("   internal resistance (open) = %f Ohms \n", dci[1].r[1]);
     printf ("   internal resistance (shorted) = %f Ohms \n", dci[1].r[2]);

     printf ("Resistor #1 value = %f Ohms \n", r[1].r[0]);
     printf ("   when failed open = %f Ohms \n", r[1].r[1]);
     printf ("   when failed shorted = %f Ohms \n", r[1].r[2]);

     printf ("Fuse #1 when healthy = %f Ohms \n", f[1].r[0]);
     printf ("   when blown = %f Ohms \n", f[1].r[1]);

     printf ("Switch #1 when open and healthy = %f Ohms \n", s[1].r[0][0]);
     printf ("        when closed and healthy = %f Ohms \n", s[1].r[1][0]);
     printf ("      when open and failed open = %f Ohms \n", s[1].r[0][1]);
     printf ("    when closed and failed open = %f Ohms \n", s[1].r[1][1]);
     printf ("   when open and failed shorted = %f Ohms \n", s[1].r[0][2]);
     printf (" when closed and failed shorted = %f Ohms \n", s[1].r[1][2]);

     printf ("Jumper #1 value = %f Ohms \n", j[1].r[0]);
     printf ("   when failed uninstalled = %f Ohms \n", j[1].r[0]);
     printf ("   when failed installed = %f Ohms \n", j[1].r[1]);

     printf ("Capacitor #1 value = %1.9f Farads \n", c[1].c);
     printf ("Capacitor #1 ESR when open = %f Ohms \n", c[1].esr[1]);
     printf ("Capacitor #1 ESR when shorted = %f Ohms \n", c[1].esr[2]);

   */


  return 0;
}
