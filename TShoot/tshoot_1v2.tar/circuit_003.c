/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 25 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 003] -- four-wire resistive sensor with DC current source

   One variable resistance powered through two multi-segment wires by
   a 100 uA current source, with voltage across the sensor measured by
   a voltmeter through two more multi-segment wires


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

int init_003 (void);
int fault_003 (void);
int sim_003 (void);

int
circuit_003 (void)
{
  clear_screen ();

  init_003 ();			// Initialize component values
  fault_003 ();			// Randomly choose a fault
  sim_003 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_003 ();

      clear_screen ();

    }

  return 0;
}




int
init_003 (void)
{

  int n;

  tp = 11;			// 11 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dci[0].h = 1;
  pot[0].h = 1;
  w[0].h = 12;

  dci[1].selected = 100e-6;	// Nominal source current value set to 100 microAmperes 
  dci[1].i[0] = random_component (dci[1].selected, dci[1].tolerance);	// Setting actual DC source current 

  pot[1].tolerance = random_component (10.0, 90.0);	// Randomly sets the potentiometer's total resistance tolerance between +/-1% and +/-19%
  pot[1].selected = pot[1].alt[2 + random_whole (7)];	// Randomly selecting nominal potentiometer value, with alt[2] being the lowest possible value
  pot[1].r_total = random_component (pot[1].selected, pot[1].tolerance);	// Setting actual pot total resistance

  for (n = 1; n <= 6; ++n)	// Randomizing wire resistance values 
    {
      w[2 * n].r[0] = random_component (2.0, 50);	// 2 Ohms +/- 50%  (i.e. 1 Ohm to 3 Ohms)
      w[(2 * n) - 1].r[0] = w[2 * n].r[0];	// Make symmetrical wire pairs have the same resistance
      // e.g. When n = 4, w[8] and w[7] set to same random value
    }

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 6;			// Voltmeter red lead on test point 6
  vm_black = 7;			// Voltmeter black lead on test point 7
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.05;			// Meter noise = +/- 0.05%

  return 0;
}




int
fault_003 (void)
{
  int n;
  int max = 14;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Wire W1 failed open";
  faults[2] = "Wire W2 failed open";
  faults[3] = "Wire W3 failed open";
  faults[4] = "Wire W4 failed open";
  faults[5] = "Wire W5 failed open";
  faults[6] = "Wire W6 failed open";
  faults[7] = "Wire W7 failed open";
  faults[8] = "Wire W8 failed open";
  faults[9] = "Wire W9 failed open";
  faults[10] = "Wire W10 failed open";
  faults[11] = "Wire W11 failed open";
  faults[12] = "Wire W12 failed open";
  faults[13] = "Dead source";
  faults[14] = "Potentiometer failed open";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_003.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("adjusting potentiometers and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf ("connected between test points TP%i and TP%i and potentiometer \n",
	  vm_red, vm_black);
  printf ("Pot 1 set to its 50 percent position. \n \n");

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 8;                  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 2;
  par_cost = 2;
  par_time = 60;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Wire W1 failed open
      w[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 2:			// Wire W2 failed open
      w[2].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 3:			// Wire W3 failed open
      w[3].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 4:			// Wire W4 failed open
      w[4].h = 1;
      par_steps = 6;
      par_cost = 13;
      break;

    case 5:			// Wire W5 failed open
      w[5].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 6:			// Wire W6 failed open
      w[6].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 7:			// Wire W7 failed open
      w[7].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 8:			// Wire W8 failed open
      w[8].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 9:			// Wire W9 failed open
      w[9].h = 1;
      par_steps = 6;
      par_cost = 13;
      break;

    case 10:			// Wire W10 failed open
      w[10].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 11:			// Wire W11 failed open
      w[11].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 12:			// Wire W12 failed open
      w[12].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 13:			// Source I1 dead
      dci[1].h = 1;
      par_steps = 3;
      par_cost = 7;
      break;

    case 14:			// Potentiometer failed open
      pot[1].h = 1;		// Open 0% terminal
      par_steps = 1;
      par_cost = 1;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_003 (void)
{
  int n, m;

  // Here we call the update_pots() function to update the resistance
  // value for each portion of each potentiometer, based on total
  // resistance (r_total) and wiper position (x).
  update_pots ();

  // Declare shorthand variables
  float r_total, r_pot, r_meas_loop, r_excite_loop, r_tps_6_7;
  float wire[13];
  float i_src, v_src, v_pot, i_meas_loop;

  r_tps_6_7 = 1e6;		// Resistance across test points 6 and 7, for voltmeter

  // Initialize shorthand variables
  for (n = 1; n <= 12; ++n)
    wire[n] = w[n].r[w[n].h];

  r_pot = pot[1].r0[pot[1].h];
  r_meas_loop = wire[5] + wire[6] + wire[7] + wire[8] + r_tps_6_7;
  r_excite_loop =
    wire[1] + wire[2] + wire[3] + wire[4] + wire[9] + wire[10] + wire[11] +
    wire[12];
  i_src = dci[1].i[dci[1].h];

  /////// Begin circuit analysis ////////
  // The strategy is to first calculate total circuit resistance, then
  // calculate source voltage based on 100 uA current times this total
  // resistance value.  If the source voltage exceeds the limit, we
  // clamp the voltage at that limiting value.  After that, we proceed
  // with calculating voltage drops and branch currents as if the 
  // source were a fixed voltage.  This way, we get correct results
  // whether or not the source has hit its limit!
  r_total = (1 / ((1 / r_meas_loop) + (1 / r_pot))) + r_excite_loop;

  // Calculate source voltage using Ohm's Law
  v_src = i_src * r_total;

  // What to do in the event of an open circuit where the current source
  // lacks a complete path for its current, causing its voltage to rise
  // to some impractical value.  
  if (v_src > 30.0)
    v_src = 30.0;

  // Now, we proceed with series-parallel network analysis as though
  // this were a voltage source rather than a current source

  // Calculate total (source) current using Ohm's Law
  i_src = v_src / r_total;

  // Set test point currents within the excitation loop to the total current value
  i_tp[0] = i_src;
  i_tp[1] = i_src;
  i_tp[2] = i_src;
  i_tp[3] = i_src;
  i_tp[4] = i_src;
  i_tp[9] = i_src;
  i_tp[10] = i_src;
  i_tp[11] = i_src;

  // Calculate potentiometer (sensor) voltage drop using Ohm's Law
  v_pot = i_src * (1 / ((1 / r_meas_loop) + (1 / r_pot)));

  // Calculate measurement loop current using Ohm's Law
  i_meas_loop = v_pot / r_meas_loop;

  // Set test point currents within the measurement loop to this same value
  i_tp[5] = i_meas_loop;
  i_tp[6] = i_meas_loop;
  i_tp[7] = i_meas_loop;
  i_tp[8] = i_meas_loop;

  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[1][0] = v_src;
  v_tp[2][0] = v_src - (i_src * wire[1]);
  v_tp[3][0] = v_src - (i_src * (wire[1] + wire[2]));
  v_tp[4][0] = v_src - (i_src * (wire[1] + wire[2] + wire[3]));
  v_tp[5][0] =
    (i_src * (wire[9] + wire[10] + wire[11] + wire[12])) +
    (i_meas_loop * (wire[6] + r_tps_6_7 + wire[7] + wire[8]));
  v_tp[6][0] =
    (i_src * (wire[9] + wire[10] + wire[11] + wire[12])) +
    (i_meas_loop * (r_tps_6_7 + wire[7] + wire[8]));
  v_tp[7][0] =
    (i_src * (wire[9] + wire[10] + wire[11] + wire[12])) +
    (i_meas_loop * (wire[7] + wire[8]));
  v_tp[8][0] =
    (i_src * (wire[9] + wire[10] + wire[11] + wire[12])) +
    (i_meas_loop * wire[8]);
  v_tp[9][0] = i_src * (wire[10] + wire[11] + wire[12]);
  v_tp[10][0] = i_src * (wire[11] + wire[12]);
  v_tp[11][0] = i_src * wire[12];

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }

  // Forcing test point-pair voltages for all combinations
  // of two series opens (i.e. when one of the sensing 
  // wires is failed open, the break between TP6-TP7 being
  // the other series open.  This assumes only one actual 
  // *fault* in the circuit at any time.

  if (wire[5] > 1e6)		// Wire W5 failed open
    {
      force_voltage (5, 0, 0.0);
      force_voltage (5, 1, 0.0);
      force_voltage (5, 2, 0.0);
      force_voltage (5, 3, 0.0);
      force_voltage (5, 4, 0.0);
      force_voltage (5, 6, 0.0);
      force_voltage (5, 7, 0.0);
      force_voltage (5, 8, 0.0);
      force_voltage (5, 9, 0.0);
      force_voltage (5, 10, 0.0);
      force_voltage (5, 11, 0.0);
    }

  if (wire[6] > 1e6)		// Wire W6 failed open
    {
      force_voltage (6, 0, 0.0);
      force_voltage (6, 1, 0.0);
      force_voltage (6, 2, 0.0);
      force_voltage (6, 3, 0.0);
      force_voltage (6, 4, 0.0);
      force_voltage (6, 5, 0.0);
      force_voltage (6, 7, 0.0);
      force_voltage (6, 8, 0.0);
      force_voltage (6, 9, 0.0);
      force_voltage (6, 10, 0.0);
      force_voltage (6, 11, 0.0);
    }

  if (wire[7] > 1e6)		// Wire W7 failed open
    {
      force_voltage (7, 0, 0.0);
      force_voltage (7, 1, 0.0);
      force_voltage (7, 2, 0.0);
      force_voltage (7, 3, 0.0);
      force_voltage (7, 4, 0.0);
      force_voltage (7, 5, 0.0);
      force_voltage (7, 6, 0.0);
      force_voltage (7, 8, 0.0);
      force_voltage (7, 9, 0.0);
      force_voltage (7, 10, 0.0);
      force_voltage (7, 11, 0.0);
    }

  if (wire[8] > 1e6)		// Wire W8 failed open
    {
      force_voltage (8, 0, 0.0);
      force_voltage (8, 1, 0.0);
      force_voltage (8, 2, 0.0);
      force_voltage (8, 3, 0.0);
      force_voltage (8, 4, 0.0);
      force_voltage (8, 5, 0.0);
      force_voltage (8, 6, 0.0);
      force_voltage (8, 7, 0.0);
      force_voltage (8, 9, 0.0);
      force_voltage (8, 10, 0.0);
      force_voltage (8, 11, 0.0);
    }

  return 0;
}
