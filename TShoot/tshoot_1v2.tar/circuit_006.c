/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 10 November 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 006] -- 4-20 mA loop-powered transmitter circuit

   One loop-powered transmitter with manually-adjustable signal (using
   a potentiometer) powered by a DC voltage source through two multi-
   segment wires.  Bridging resistances inserted into the circuit 
   between these wires simulate shorted-cable conditions.


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

float r_A, r_B, r_C, r_xmtr;	// Cable insulation resistance and transmitter resistance variables
float xmtr_span, xmtr_zero;	// Transmitter calibration parameters

int init_006 (void);
int fault_006 (void);
int sim_006 (void);

int
circuit_006 (void)
{
  clear_screen ();

  init_006 ();			// Initialize component values
  fault_006 ();			// Randomly choose a fault
  sim_006 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_006 ();

      clear_screen ();

    }

  return 0;
}




int
init_006 (void)
{

  int n;

  tp = 9;			// 9 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 1;
  r[0].h = 1;
  pot[0].h = 1;
  w[0].h = 6;
  f[0].h = 1;

  dcv[1].alt[0] = 24.0;		// Establishing new nominal DC voltage source values
  dcv[1].alt[1] = 25.0;		// appropriate for powering an industrial loop-
  dcv[1].alt[2] = 26.0;		// powered 4-20 mA transmitter.
  dcv[1].alt[3] = 27.0;
  dcv[1].alt[4] = 28.0;
  dcv[1].alt[5] = 29.0;
  dcv[1].alt[6] = 30.0;
  dcv[1].alt[7] = 31.0;
  dcv[1].alt[8] = 32.0;
  dcv[1].alt[9] = 33.0;

  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance);	// Setting actual DC source voltage 

  for (n = 1; n <= 3; ++n)	// Randomizing wire resistance values 
    {
      w[2 * n].r[0] = random_component (2.0, 50);	// 2 Ohms +/- 50%  (i.e. 1 Ohm to 3 Ohms)
      w[(2 * n) - 1].r[0] = w[2 * n].r[0];	// Make symmetrical wire pairs have the same resistance
      // e.g. When n = 2, w[4] and w[3] set to same random value
    }

  // Set "healthy" values for precision resistor R1 to be 250.0 ohms exactly
  r[1].selected = 250.0;
  r[1].tolerance = 0.05;	// precision resistor with +/- 0.05% tolerance
  r[1].r[0] = random_component (r[1].selected, r[1].tolerance);	// Set actual resistance to selected value with tolerance

  // Set "healthy" values for cable resistances RA, RB, and RC to be essentially open
  r_A = 9e8;
  r_B = 9e8;
  r_C = 9e8;

  // Set "healthy" values for transmitter resistance to be 1000 Ohms
  r_xmtr = 1000.0;

  // The potentiometer fulfills no electrical function in this circuit, but really
  // only serves as an adjustment for the transmitter's 4-20 mA output.  Therefore,
  // pot[1].x is really the only variable that matters electrically in this circuit.
  // However, for the sake of providing random numerical values for which to identify
  // which randomized scenario each student receives, we allow the potentiometer's
  // selected resistance value as well as its tolerance be randomized here.
  pot[1].x = random_component (0.5, 90);	// Setting transmitter pot to 50% +/- 45%
  pot[1].tolerance = random_component (10.0, 90.0);	// Randomly sets the potentiometer's total resistance tolerance between +/-1% and +/-19%
  pot[1].selected = pot[1].alt[2 + random_whole (7)];	// Randomly selecting nominal potentiometer value, with alt[2] being the lowest possible value

  xmtr_zero = random_component (4e-3, 0.25);	// Setting calibrated "zero" point at 4 mA +/- 0.25%
  xmtr_span = random_component (16e-3, 0.25);	// Setting calibrated "span" to be 16 mA +/- 0.25%

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 2;			// Voltmeter red lead on test point 6
  vm_black = 0;			// Voltmeter black lead on test point 7
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.05;			// Meter noise = +/- 0.05%

  return 0;
}




int
fault_006 (void)
{
  int n;
  int max = 20;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Wire W1 failed open";
  faults[2] = "Wire W2 failed open";
  faults[3] = "Wire W3 failed open";
  faults[4] = "Wire W4 failed open";
  faults[5] = "Wire W5 failed open";
  faults[6] = "Wire W6 failed open";
  faults[7] = "Dead source";
  faults[8] = "Fuse open (blown)";
  faults[9] = "Resistor R1 failed open";
  faults[10] = "Resistor R1 failed shorted";
  faults[11] = "Cable A severed (both conductors failed open)";
  faults[12] = "Cable B severed (both conductors failed open)";
  faults[13] = "Cable C severed (both conductors failed open)";
  faults[14] = "Cable A failed shorted";
  faults[15] = "Cable B failed shorted";
  faults[16] = "Cable C failed shorted";
  faults[17] = "Transmitter failed open";
  faults[18] = "Transmitter failed shorted";
  faults[19] = "Transmitter zero shift (worse than +/-1%)";
  faults[20] = "Transmitter span shift (worse than +/-1%)";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_006.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("adjusting potentiometers and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf
    ("connected between test points TP%i and TP%i and the transmitter's \n",
     vm_red, vm_black);
  printf
    ("potentiometer (Pot 1) set to a random position.  Please note the \n");
  printf ("potentiometer's nominal value in Ohms is irrelevant, as the \n");
  printf
    ("transmitter's internal circuitry responds only to wiper position. \n \n");

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 18;                 // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 3;
  par_cost = 4;
  par_time = 60;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Wire W1 failed open
      w[1].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 2:			// Wire W2 failed open
      w[2].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 3:			// Wire W3 failed open
      w[3].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 4:			// Wire W4 failed open
      w[4].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 5:			// Wire W5 failed open
      w[5].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 6:			// Wire W6 failed open
      w[6].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 7:			// Source V1 dead, open
      dcv[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 8:			// Fuse blown
      f[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 9:			// Resistor R1 failed open
      r[1].h = 1;
      par_steps = 3;
      par_cost = 7;
      break;

    case 10:			// Resistor R1 failed shorted
      r[1].h = 2;
      par_steps = 5;
      par_cost = 11;
      break;

    case 11:			// Cable A severed
      w[1].h = 1;		// Both conductors failed open
      w[2].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 12:			// Cable B severed
      w[3].h = 1;		// Both conductors failed open
      w[4].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 13:			// Cable C severed
      w[5].h = 1;		// Both conductors failed open
      w[6].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 14:			// Cable A failed shorted
      r_A = 1e-1;
      par_steps = 5;
      par_cost = 17;
      break;

    case 15:			// Cable B failed shorted
      r_B = 1e-1;
      par_steps = 5;
      par_cost = 17;
      break;

    case 16:			// Cable C failed shorted
      r_C = 1e-1;
      par_steps = 5;
      par_cost = 17;
      break;

    case 17:			// Transmitter failed open
      r_xmtr = 9e8;
      par_steps = 5;
      par_cost = 11;
      break;

    case 18:			// Transmitter failed shorted
      r_xmtr = 1e-1;
      par_steps = 5;
      par_cost = 17;
      break;

    case 19:			// Transmitter zero shift
      while (xmtr_zero < 4.05e-3 && xmtr_zero > 3.95e-3)
	{
	  xmtr_zero = random_component (4e-3, 10);	// Randomly shift zero up to +/- 10%
	}
      par_steps = 4;
      par_cost = 3;
      break;

    case 20:			// Transmitter span shift
      while (xmtr_span < 16.2e-3 && xmtr_span > 15.8e-3)
	{
	  xmtr_span = random_component (16e-3, 10);	// Randomly shift zero up to +/- 10%
	}
      par_steps = 4;
      par_cost = 3;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;         // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;          // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;          // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_006 (void)
{
  int n, m;

  // Here we call the update_pots() function to update the resistance
  // value for each portion of each potentiometer, based on total
  // resistance (r_total) and wiper position (x).
  update_pots ();

  // Declare shorthand variables
  float r_total, r1, r_fuse;
  float wire[7];
  float r_loop_34, r_loop_56, r_loop_78;	// Equivalent resistances for portions of loop
  float i_src, v_src;
  float i_A, i_B, i_C, i_xmtr, v_xmtr;

  // Initialize shorthand variables
  for (n = 1; n <= 6; ++n)
    wire[n] = w[n].r[w[n].h];

  r1 = r[1].r[r[1].h];
  r_fuse = f[1].r[f[1].h];

  v_src = dcv[1].v[dcv[1].h];

  /////// Begin circuit analysis ////////
  // The strategy is to first calculate total circuit resistance, then
  // calculate voltage at the transmitter terminals (TP7-TP8) to see 
  // if it's at least 15 Volts, which is a common minimum operating
  // voltage for industrial loop-powered transmitters.  If so, then
  // assume the transmitter will function as a current-regulating
  // device and set loop current proportional to potentiometer position
  // and calculate voltages in the circuit ignoring all the cable
  // cable insulation resistances (i.e. RA-RC) which cannot be shorted
  // if the transmitter is receiving at least 15 Volts.  If the 
  // transmitter's voltage is less than 15 Volts, we treat the 
  // transmitter as a simple resistance (1 k Ohms) and calculate all
  // test point voltages based on the source voltage and series-
  // parallel analysis.
  r_loop_78 = wire[5] + wire[6] + (1 / ((1 / r_C) + (1 / r_xmtr)));
  r_loop_56 = wire[3] + wire[4] + (1 / ((1 / r_B) + (1 / r_loop_78)));
  r_loop_34 = wire[1] + wire[2] + (1 / ((1 / r_A) + (1 / r_loop_56)));
  r_total = r_fuse + r1 + r_loop_34;

  // Calculate source current using Ohm's Law
  i_src = v_src / r_total;

  i_A = i_src;			// Cable A's current equal to source current
  i_B = i_A * ((r_loop_34 - wire[1] - wire[2]) / r_loop_56);	// Current-divider formula
  i_C = i_B * ((r_loop_56 - wire[3] - wire[4]) / r_loop_78);	// Current-divider formula
  i_xmtr = i_C * ((r_loop_78 - wire[5] - wire[6]) / r_xmtr);	// Current-divider formula

  // Calculating transmitter terminal voltage
  v_xmtr = i_xmtr * r_xmtr;

  if (v_xmtr < 15 || r_xmtr < 1e2 || r_xmtr > 1e4)	// Transmitter is starved for voltage and/or failed; behaves as simple resistance
    {
      // Set test point currents 
      i_tp[0] = i_src;
      i_tp[1] = i_A;
      i_tp[2] = i_A;
      i_tp[3] = i_B;
      i_tp[4] = i_B;
      i_tp[5] = i_C;
      i_tp[6] = i_C;
      i_tp[7] = i_xmtr;
      i_tp[8] = i_xmtr;
      i_tp[9] = i_src;

      // Calculate all test point voltages with respect to ground (TP 0)
      v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
      v_tp[1][0] = v_src - (i_src * r_fuse);
      v_tp[2][0] = i_src * r1;
      v_tp[3][0] = v_tp[1][0] - (i_A * wire[1]);
      v_tp[4][0] = v_tp[2][0] + (i_A * wire[2]);
      v_tp[5][0] = v_tp[3][0] - (i_B * wire[3]);
      v_tp[6][0] = v_tp[4][0] + (i_B * wire[4]);
      v_tp[7][0] = v_tp[5][0] - (i_C * wire[5]);
      v_tp[8][0] = v_tp[6][0] + (i_C * wire[6]);
      v_tp[9][0] = v_src;

      // Calculate all test point-pair voltages
      for (n = 0; n < COUNT; ++n)
	{
	  for (m = 0; m < COUNT; ++m)
	    v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
	}

      // Forcing test point-pair voltages for all combinations
      // of two series opens (i.e. severed cable)
      if (wire[1] > 1e6 && wire[2] > 1e6)	// Cable A severed -- wires 1 and 2 open
	{
	  for (n = 3; n <= 8; ++n)	// Sets voltage to zero for all test points 3 through 8
	    {
	      for (m = 0; m <= tp; ++m)
		force_voltage (n, m, 0.0);
	    }
	}

      if (wire[3] > 1e6 && wire[4] > 1e6)	// Cable B severed -- wires 3 and 4 open
	{
	  for (n = 5; n <= 8; ++n)	// Sets voltage to zero for all test points 5 through 8
	    {
	      for (m = 0; m <= tp; ++m)
		force_voltage (n, m, 0.0);
	    }
	}

      if (wire[5] > 1e6 && wire[6] > 1e6)	// Cable C severed -- wires 5 and 6 open
	{
	  for (n = 7; n <= 8; ++n)	// Sets voltage to zero for test points 7 and 8
	    {
	      for (m = 0; m <= tp; ++m)
		force_voltage (n, m, 0.0);
	    }
	}

    }

  else				// Transmitter is NOT starved for voltage NOR failed and is able to regulate loop current
    {
      i_xmtr = (pot[1].x * xmtr_span) + xmtr_zero;	// 4-20 mA current value set by pot position

      for (n = 0; n <= tp; ++n)	// All test point currents equal to transmitter current
	i_tp[n] = i_xmtr;

      // Calculate all test point voltages with respect to ground (TP 0)
      v_tp[0][0] = 0;		// TP 0 (ground) is 0 Volts by definition . . .
      v_tp[1][0] = v_src - (i_xmtr * r_fuse);
      v_tp[2][0] = i_xmtr * r1;
      v_tp[3][0] = v_tp[1][0] - (i_xmtr * wire[1]);
      v_tp[4][0] = v_tp[2][0] + (i_xmtr * wire[2]);
      v_tp[5][0] = v_tp[3][0] - (i_xmtr * wire[3]);
      v_tp[6][0] = v_tp[4][0] + (i_xmtr * wire[4]);
      v_tp[7][0] = v_tp[5][0] - (i_xmtr * wire[5]);
      v_tp[8][0] = v_tp[6][0] + (i_xmtr * wire[6]);
      v_tp[9][0] = v_src;

      // Calculate all test point-pair voltages
      for (n = 0; n < COUNT; ++n)
	{
	  for (m = 0; m < COUNT; ++m)
	    v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
	}
    }

  return 0;
}
