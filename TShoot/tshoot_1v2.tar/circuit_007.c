/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 10 November 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 007] -- 4-20 mA externally-powered transmitter circuit

   One exterally-powered (i.e. "4-wire") 4-20 mA transmitter with 
   manually-adjustable signal (using a potentiometer) powered by 
   a DC voltage source through two multi-segment wires.  


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

float r_xmtr;			// Transmitter (power terminals) resistance variable
float xmtr_span, xmtr_zero;	// Transmitter calibration parameters

int init_007 (void);
int fault_007 (void);
int sim_007 (void);

int
circuit_007 (void)
{
  clear_screen ();

  init_007 ();			// Initialize component values
  fault_007 ();			// Randomly choose a fault
  sim_007 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_007 ();

      clear_screen ();

    }

  return 0;
}




int
init_007 (void)
{

  int n;

  tp = 17;			// 17 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 1;
  r[0].h = 1;
  pot[0].h = 1;
  w[0].h = 12;
  f[0].h = 1;

  dcv[1].alt[0] = 24.0;		// Establishing new nominal DC voltage source values
  dcv[1].alt[1] = 25.0;		// appropriate for powering an industrial 4-20 mA
  dcv[1].alt[2] = 26.0;		// transmitter.
  dcv[1].alt[3] = 27.0;
  dcv[1].alt[4] = 28.0;
  dcv[1].alt[5] = 29.0;
  dcv[1].alt[6] = 30.0;
  dcv[1].alt[7] = 31.0;
  dcv[1].alt[8] = 32.0;
  dcv[1].alt[9] = 33.0;

  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance);	// Setting actual DC source voltage 

  for (n = 1; n <= 3; ++n)	// Randomizing wire resistance values 
    {
      // Make every wire in each cable have the same resistance.  E.g. when
      // n = 2, w[4], w[3], w[10], and w[9] all set to the same random value
      w[2 * n].r[0] = random_component (2.0, 50);	// 2 Ohms +/- 50%  (i.e. 1 Ohm to 3 Ohms)
      w[(2 * n) - 1].r[0] = w[2 * n].r[0];
      w[(2 * n) + 6].r[0] = w[2 * n].r[0];
      w[(2 * n) + 5].r[0] = w[2 * n].r[0];
    }

  // Set "healthy" values for precision resistor R1 to be 250.0 ohms exactly
  r[1].selected = 250.0;
  r[1].tolerance = 0.05;	// precision resistor with +/- 0.05% tolerance
  r[1].r[0] = random_component (r[1].selected, r[1].tolerance);	// Set actual resistance to selected value with tolerance

  // Set "healthy" values for transmitter resistance to be 780 Ohms
  r_xmtr = 780.0;

  // The potentiometer fulfills no electrical function in this circuit, but really
  // only serves as an adjustment for the transmitter's 4-20 mA output.  Therefore,
  // pot[1].x is really the only variable that matters electrically in this circuit.
  // However, for the sake of providing random numerical values for which to identify
  // which randomized scenario each student receives, we allow the potentiometer's
  // selected resistance value as well as its tolerance be randomized here.
  pot[1].x = random_component (0.5, 90);	// Setting transmitter pot to 50% +/- 45%
  pot[1].tolerance = random_component (10.0, 90.0);	// Randomly sets the potentiometer's total resistance tolerance between +/-1% and +/-19%
  pot[1].selected = pot[1].alt[2 + random_whole (7)];	// Randomly selecting nominal potentiometer value, with alt[2] being the lowest possible value

  xmtr_zero = random_component (4e-3, 0.25);	// Setting calibrated "zero" point at 4 mA +/- 0.25%
  xmtr_span = random_component (16e-3, 0.25);	// Setting calibrated "span" to be 16 mA +/- 0.25%

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 1;			// Voltmeter red lead on test point 6
  vm_black = 2;			// Voltmeter black lead on test point 7
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.05;			// Meter noise = +/- 0.05%

  return 0;
}




int
fault_007 (void)
{
  int n;
  int max = 18;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Wire W1 failed open";
  faults[2] = "Wire W2 failed open";
  faults[3] = "Wire W3 failed open";
  faults[4] = "Wire W4 failed open";
  faults[5] = "Wire W5 failed open";
  faults[6] = "Wire W6 failed open";
  faults[7] = "Wire W7 failed open";
  faults[8] = "Wire W8 failed open";
  faults[9] = "Wire W9 failed open";
  faults[10] = "Wire W10 failed open";
  faults[11] = "Wire W11 failed open";
  faults[12] = "Wire W12 failed open";
  faults[13] = "Dead source";
  faults[14] = "Fuse open (blown)";
  faults[15] = "Resistor R1 failed open";
  faults[16] = "Resistor R1 failed shorted";
  faults[17] = "Transmitter zero shift (worse than +/-1%)";
  faults[18] = "Transmitter span shift (worse than +/-1%)";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_007.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("adjusting potentiometers and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf
    ("connected between test points TP%i and TP%i and the transmitter's \n",
     vm_red, vm_black);
  printf
    ("potentiometer (Pot 1) set to a random position.  Please note the \n");
  printf ("potentiometer's nominal value in Ohms is irrelevant, as the \n");
  printf
    ("transmitter's internal circuitry responds only to wiper position. \n \n");

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 18;                 // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 3;
  par_cost = 4;
  par_time = 60;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Wire W1 failed open
      w[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 2:			// Wire W2 failed open
      w[2].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 3:			// Wire W3 failed open
      w[3].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 4:			// Wire W4 failed open
      w[4].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 5:			// Wire W5 failed open
      w[5].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 6:			// Wire W6 failed open
      w[6].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 7:			// Wire W7 failed open
      w[7].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 8:			// Wire W8 failed open
      w[8].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 9:			// Wire W9 failed open
      w[9].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 10:			// Wire W10 failed open
      w[10].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 11:			// Wire W11 failed open
      w[11].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 12:			// Wire W12 failed open
      w[12].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 13:			// Source V1 dead, open
      dcv[1].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 14:			// Fuse blown
      f[1].h = 1;
      par_steps = 7;
      par_cost = 12;
      break;

    case 15:			// Resistor R1 failed open
      r[1].h = 1;
      par_steps = 2;
      par_cost = 2;
      break;

    case 16:			// Resistor R1 failed shorted
      r[1].h = 2;
      par_steps = 4;
      par_cost = 6;
      break;

    case 17:			// Transmitter zero shift
      while (xmtr_zero < 4.05e-3 && xmtr_zero > 3.95e-3)
	{
	  xmtr_zero = random_component (4e-3, 10);	// Randomly shift zero up to +/- 10%
	}
      par_steps = 4;
      par_cost = 4;
      break;

    case 18:			// Transmitter span shift
      while (xmtr_span < 16.2e-3 && xmtr_span > 15.8e-3)
	{
	  xmtr_span = random_component (16e-3, 10);	// Randomly shift zero up to +/- 10%
	}
      par_steps = 4;
      par_cost = 4;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_007 (void)
{
  int n, m;

  // Here we call the update_pots() function to update the resistance
  // value for each portion of each potentiometer, based on total
  // resistance (r_total) and wiper position (x).
  update_pots ();

  // Declare shorthand variables
  float r_loop_power, r_loop_signal, r1, r_fuse;
  float wire[13];
  float i_src, v_src;
  float i_xmtr, v_xmtr, v_power;

  // Initialize shorthand variables
  for (n = 1; n <= 12; ++n)
    wire[n] = w[n].r[w[n].h];

  r1 = r[1].r[r[1].h];
  r_fuse = f[1].r[f[1].h];

  v_src = dcv[1].v[dcv[1].h];

  /////// Begin circuit analysis ////////
  // The strategy is to first calculate loop power (outer wires) 
  // circuit resistance, then calculate voltage at the transmitter 
  // power terminals (TP15-TP16) to see if it's at least 15 Volts, 
  // which is a common minimum operating voltage for industrial 
  // 4-20 mA transmitters.  If so, assume the transmitter will 
  // function as a current source and set transmitter current 
  // proportional to potentiometer position.  If not, set 
  // transmitter current to zero milliAmperes.
  //
  // For the signal loop (inner wires), we first calculate loop 
  // resistance, then calculate source voltage based on transmitter 
  // current times this loop resistance value.  If the source 
  // voltage exceeds the voltage between the transmitter's power
  // terminals (TP15-TP16), then clamp the source voltage at that 
  // limiting value.  After that, we proceed with calculating 
  // voltage drops and branch currents as if the source were a 
  // fixed voltage.  This way, we get correct results whether or 
  // not the source has hit its limit!

  // Calculating loop resistances
  r_loop_power =
    r_fuse + wire[7] + wire[9] + wire[11] + r_xmtr + wire[12] + wire[10] +
    wire[8];
  r_loop_signal =
    r1 + wire[1] + wire[3] + wire[5] + wire[6] + wire[4] + wire[2];

  // Calculate source current using Ohm's Law
  i_src = v_src / r_loop_power;

  for (n = 1; n <= 9; ++n)	// All power loop test point currents equal to source current
    i_tp[n + 8] = i_src;

  // Calculate voltage across transmitter power terminals (TP15-TP16)
  v_power = i_src * r_xmtr;

  if (v_power < 15.0)		// Transmitter starved for voltage
    i_xmtr = 0.0;

  else				// Transmitter has enough power to function properly
    i_xmtr = (pot[1].x * xmtr_span) + xmtr_zero;	// 4-20 mA current value set by pot position

  // Calculate voltage across transmitter signal terminals (TP7-TP8)
  v_xmtr = i_xmtr * r_loop_signal;

  if (v_xmtr > v_power)		// Signal loop has too much resistance!
    v_xmtr = v_power - 0.5;	// Output hits limit just less than power supply voltage

  i_xmtr = v_xmtr / r_loop_signal;

  for (n = 1; n <= 8; ++n)	// All signal loop test point currents equal to transmitter current
    i_tp[n] = i_xmtr;

  // Now, we proceed with series network analysis as though the transmitter
  // were a voltage source rather than a current source

  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[16][0] = 0.0;		// TP16 electrically common to TP0 (ground)
  v_tp[8][0] = 0.0;		// TP8 also electrically common to TP0 (ground)
  v_tp[14][0] = -i_src * wire[12];
  v_tp[12][0] = v_tp[14][0] - (i_src * wire[10]);
  v_tp[10][0] = v_tp[12][0] - (i_src * wire[8]);
  v_tp[17][0] = v_tp[10][0] + v_src;
  v_tp[9][0] = v_tp[17][0] - (i_src * r_fuse);
  v_tp[11][0] = v_tp[9][0] - (i_src * wire[7]);
  v_tp[13][0] = v_tp[11][0] - (i_src * wire[9]);
  v_tp[15][0] = v_tp[13][0] - (i_src * wire[11]);
  v_tp[6][0] = i_xmtr * wire[6];
  v_tp[4][0] = v_tp[6][0] + (i_xmtr * wire[4]);
  v_tp[2][0] = v_tp[4][0] + (i_xmtr * wire[2]);
  v_tp[1][0] = v_tp[2][0] + (i_xmtr * r1);
  v_tp[3][0] = v_tp[1][0] + (i_xmtr * wire[1]);
  v_tp[5][0] = v_tp[3][0] + (i_xmtr * wire[3]);
  v_tp[7][0] = v_tp[5][0] + (i_xmtr * wire[5]);

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }


  return 0;
}
