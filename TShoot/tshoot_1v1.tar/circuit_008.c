/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 008] -- relay-controlled motor circuit

   One electric motor (5 horsepower) turned on and off by an
   electromechanical relay, controlled by a toggle switch


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

int init_008 (void);
int fault_008 (void);
int sim_008 (void);

int
circuit_008 (void)
{
  clear_screen ();

  init_008 ();			// Initialize component values
  fault_008 ();			// Randomly choose a fault
  sim_008 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_008 ();

      clear_screen ();

    }

  return 0;
}




int
init_008 (void)
{

  tp = 6;			// 6 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 2;
  r[0].h = 1;			// Representing the relay coil as a resistor
  ld[0].h = 1;			// Representing the motor as a generic load
  s[0].h = 1;
  f[0].h = 2;

  dcv[1].alt[0] = 24.0;		// Establishing new nominal DC voltage source values
  dcv[1].alt[1] = 25.0;		// appropriate for powering an industrial relay.
  dcv[1].alt[2] = 26.0;
  dcv[1].alt[3] = 27.0;
  dcv[1].alt[4] = 28.0;
  dcv[1].alt[5] = 29.0;
  dcv[1].alt[6] = 30.0;
  dcv[1].alt[7] = 31.0;
  dcv[1].alt[8] = 32.0;
  dcv[1].alt[9] = 33.0;

  dcv[1].tolerance = random_component (5.0, 75.0);	// Randomly sets the source's tolerance between +/-1.25% and +/-8.75%
  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance);	// Setting actual DC source voltage

  dcv[2].alt[0] = 48.0;		// Establishing new nominal DC voltage source values
  dcv[2].alt[1] = 110.0;	// appropriate for powering a 5 HP electric motor.
  dcv[2].alt[2] = 115.0;
  dcv[2].alt[3] = 117.0;
  dcv[2].alt[4] = 120.0;
  dcv[2].alt[5] = 125.0;
  dcv[2].alt[6] = 220.0;
  dcv[2].alt[7] = 230.0;
  dcv[2].alt[8] = 240.0;
  dcv[2].alt[9] = 250.0;

  dcv[2].tolerance = random_component (5.0, 75.0);	// Randomly sets the source's tolerance between +/-1.25% and +/-8.75%
  dcv[2].selected = dcv[2].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
  dcv[2].v[0] = random_component (dcv[2].selected, dcv[2].tolerance);	// Setting actual DC source voltage

  f[1].imax = 1.0;		// Maximum fuse current set to 1.0 Ampere
  f[2].r[0] = 5.2e-3;		// Motor fuse has resistance of 0.0052 Ohms
  f[2].imax = 100.0;		// Maximum fuse current set to 100.0 Amperes

  r[1].tolerance = random_component (10.0, 50.0);	// Randomly sets the relay coil resistance tolerance between +/-5% and +/-15%
  r[1].selected = dcv[1].selected / 0.100;	// Selecting relay coil resistance based on the DC voltage
  // source nominal value and a nominal 100 mA coil current
  r[1].r[0] = random_component (r[1].selected, r[1].tolerance);	// Setting actual relay coil resistance value


  ld[1].d = "Motor";		// Giving our load a name (motor)
  ld[1].r[0] = pow (dcv[2].selected, 2) / (5.0 * 746.0);	// Selecting motor resistance based on the DC voltage source nominal value and the 5 HP rating

  vm_red = 6;			// Voltmeter red lead on test point 8
  vm_black = 0;			// Voltmeter black lead on test point 9
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  noise = 0.01;			// Meter noise = +/- 0.01%

  return 0;
}




int
fault_008 (void)
{
  int n;
  int max = 10;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Dead source V1";
  faults[2] = "Dead source V2";
  faults[3] = "Fuse F1 open (blown)";
  faults[4] = "Fuse F2 open (blown)";
  faults[5] = "Motor failed open";
  faults[6] = "Relay coil failed open";
  faults[7] = "Relay contact failed open";
  faults[8] = "Relay contact failed shorted";
  faults[9] = "Switch S1 failed open";
  faults[10] = "Switch S1 failed shorted";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_008.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("toggling switches and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf ("connected between test points TP%i and TP%i. \n \n",
	  vm_red, vm_black);

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 8;                 // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 3;
  par_cost = 3;
  par_time = 60;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Dead source V1
      dcv[1].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 2:			// Dead source V2
      dcv[2].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 3:			// Fuse F1 open (blown)
      f[1].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 4:			// Fuse F2 open (blown)
      f[2].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 5:			// Motor failed open
      ld[1].h = 1;
      par_steps = 3;
      par_cost = 3;
      break;

    case 6:			// Relay coil failed open
      r[1].h = 1;
      par_steps = 6;
      par_cost = 12;
      break;

    case 7:			// Relay contact failed open
      rc[1].h = 1;
      par_steps = 6;
      par_cost = 12;
      break;

    case 8:			// Relay contact failed shorted
      rc[1].h = 2;
      par_steps = 3;
      par_cost = 4;
      break;

    case 9:			// Switch S1 failed open
      s[1].h = 1;
      par_steps = 5;
      par_cost = 7;
      break;

    case 10:			// Switch S1 failed shorted
      s[1].h = 2;
      par_steps = 3;
      par_cost = 4;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_008 (void)
{
  int n, m;

  // Declare shorthand variables
  float r_coiltotal, r_motortotal;
  float r_coil, r_motor, r_fuse1, r_fuse2;
  float r_switch, r_contact;
  float i1_src, v1_src, i2_src, v2_src;
  float v_coil;

  // Initialize shorthand variables

  r_coil = r[1].r[r[1].h];

  r_motor = ld[1].r[ld[1].h];

  r_fuse1 = f[1].r[f[1].h];

  r_fuse2 = f[2].r[f[2].h];

  r_switch = s[1].r[s[1].s][s[1].h];

  v1_src = dcv[1].v[dcv[1].h];

  v2_src = dcv[2].v[dcv[2].h];

  // Calculating total resistance of relay coil circuit
  r_coiltotal = r_fuse1 + r_switch + r_coil;

  // Calculate source V1 current using Ohm's Law
  i1_src = v1_src / r_coiltotal;

  // Set test point currents in relay coil circuit
  i_tp[1] = i1_src;
  i_tp[2] = i1_src;
  i_tp[3] = i1_src;

  // Calculate voltage dropped across relay coil
  v_coil = i1_src * r_coil;

  // Set relay contact status based on relay coil voltage and current;
  // current must exceed 50 mA and voltage must exceed half of v1_src
  if (i1_src > 0.05 && v_coil > (v1_src / 2))
    rc[1].s = 1;

  else
    rc[1].s = 0;

  r_contact = rc[1].r[rc[1].s][rc[1].h];

  // Calculating total resistance of motor circuit
  r_motortotal = r_fuse2 + r_contact + r_motor;

  // Calculate source V2 current using Ohm's Law
  i2_src = v2_src / r_motortotal;

  // Set test point currents in motor circuit
  i_tp[4] = i2_src;
  i_tp[5] = i2_src;
  i_tp[6] = i2_src;

  // Calculate motor voltage drop using Ohm's Law
  ld[1].v = i2_src * r_motor;

  // Source V2 current is the motor current
  ld[1].i = i2_src;

  // Here we call the update_loads() function to update the 
  // energization statuses of all loads in the circuit, based
  // on load voltage and load current.
  update_loads ();





  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[1][0] = v1_src;
  v_tp[2][0] = v1_src - (i1_src * r_fuse1);
  v_tp[3][0] = v_coil;
  v_tp[4][0] = v2_src;
  v_tp[5][0] = v2_src - (i2_src * r_fuse2);
  v_tp[6][0] = ld[1].v;

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }

  // Forcing test point-pair voltages for all combinations
  // of two series opens (i.e. when both the switch and one
  // other component are failed open).  This assumes only
  // one actual *fault* in the circuit at any time.
  if (r_switch > 1e6 && r_fuse1 > 1e6)	// Switch and fuse 1 both open leaving TP2 floating
    {
      force_voltage (2, 0, 0.0);
      force_voltage (2, 1, 0.0);
      force_voltage (2, 3, 0.0);
      force_voltage (2, 4, 0.0);
      force_voltage (2, 5, 0.0);
      force_voltage (2, 6, 0.0);
    }

  if (r_switch > 1e6 && r_coil > 1e6)	// Switch and relay coil both open leaving TP3 floating
    {
      force_voltage (3, 0, 0.0);
      force_voltage (3, 1, 0.0);
      force_voltage (3, 2, 0.0);
      force_voltage (3, 4, 0.0);
      force_voltage (3, 5, 0.0);
      force_voltage (3, 6, 0.0);
    }

  if (r_contact > 1e6 && r_fuse2 > 1e6)	// Relay contact and fuse 2 both open leaving TP5 floating
    {
      force_voltage (5, 0, 0.0);
      force_voltage (5, 1, 0.0);
      force_voltage (5, 2, 0.0);
      force_voltage (5, 3, 0.0);
      force_voltage (5, 4, 0.0);
      force_voltage (5, 6, 0.0);
    }

  if (r_contact > 1e6 && r_motor > 1e6)	// Relay contact and motor both open leaving TP6 floating
    {
      force_voltage (6, 0, 0.0);
      force_voltage (6, 1, 0.0);
      force_voltage (6, 2, 0.0);
      force_voltage (6, 3, 0.0);
      force_voltage (6, 4, 0.0);
      force_voltage (6, 5, 0.0);
    }

  return 0;
}
