/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

*************************************************************************/

#define COUNT 25



/**************************************************************************** 
			General function prototypes 
****************************************************************************/

float random_component (float, float);
int random_whole (int);
int blank_slate (void);
int clear_screen (void);
int force_voltage (int, int, float);
int force_all_voltages (float);
int toggle_switch (int);
int adjust_potentiometer (int);
int place_jumper (int);
int move_voltmeter (int);
int move_ammeter (int);
int print_components (int);
int print_measurements (void);
int user_test (void);
int update_pots (void);
int update_loads (void);
int declare_fault (void);
int debrief (void);


/**************************************************************************** 
			Circuit function prototypes 
****************************************************************************/

int circuit_000 (void);		// Simple one-resistor circuit with DC voltage source
int circuit_001 (void);		// Three-resistor voltage divider with DC voltage source
int circuit_002 (void);		// Three-resistor current divider with DC current source
int circuit_003 (void);		// Four-wire resistive sensor with DC current source
int circuit_004 (void);		// Loaded voltage divider with DC voltage source
int circuit_005 (void);		// Adjustable Wheatstone bridge with DC voltage source
int circuit_006 (void);		// 4-20 mA loop-powered transmitter circuit
int circuit_007 (void);		// 4-20 mA externally-powered transmitter circuit
int circuit_008 (void);		// Relay-controlled motor circuit




/**************************************************************************** 
		Declare global status variables 
****************************************************************************/

char username[40];		// 40-character string for the user's name

int step;			// Number of steps taken, as a running total

int cost;			// The "cost" of each diagnostic test, as a running total

int par_steps;			// A reasonable number of diagnostic steps performed
int par_cost;			// A reasonable "cost" of diagnostic steps performed, in dollars
int par_time;			// A reasonable time to perform all diagnostic steps, in seconds

int limit_steps;		// Maximum number of diagnostic steps allowed
int limit_cost;			// Maximum "cost" of diagnostic steps budgeted
int limit_time;			// Maximum time to perform all diagnostic steps, in seconds

int fault;			// A number representing which fault exists in the circuit
				//   no fault = 0 (all healthy)

int conclusion;			// A number representing the user's conclusion of fault
				//  -1 = default (i.e. user has not made a selection yet)
				//   0 = no fault (i.e. all components healthy)

float noise;			// The percentage of meter measurement noise

int vm_red;			// Test point number for red lead of voltmeter
int vm_black;			// Test point number for black lead of voltmeter
int vm_cost;			// Cost of moving test leads for the voltmeter

int am_tp;			// Test point number for ammeter
int am_cost;			// Cost of moving the ammeter

int j_cost;			// Cost of inserting a temporary jumper wire

int mistake;			// 0 = no mistakes
				// 1 = blew a fuse
				// 2 = took too many steps
				// 3 = spent too much money
				// 4 = took too much time

struct steps_taken		// Array of structures describing each step taken
{
  char code;			// Single-letter code describing the step taken
  char *d;			// Text string containing a description of step
  float vm;			// Voltmeter measurement value
  float am;			// Ammeter measurement value
  float adjust;			// Component adjustment value
  int vtp[2];			// Voltmeter test points [0] = red, [1] = black
  int atp;			// Ammeter test point
  int jtp[2];			// Jumper wire test points [0] = red, [1] = black
  int num;			// Component number
  int cost;			// Cost of diagnostic step
  int time;			// Time of diagnostic step, from time_start (in seconds)
  char *r;			// Text string containing a reason for step
} steplog[100];

int time_finish;		// This is the ending UNIX system time cast into integer format
				// The starting time is steplog[0].time



/**************************************************************************** 
	Declare circuit component structures and variables 
****************************************************************************/


//--------------------------------------------------------------------------

float v_tp[COUNT][COUNT];	// Array of test point pair voltages 

float i_tp[COUNT];		// Array of test point currents

int tp;				// Number of test points in circuit

char *faults[COUNT];		// Array of strings storing text descriptions of each fault

//--------------------------------------------------------------------------

struct dc_v_source		// Array of DC voltage sources for circuit
{
  int h;			// Health status of source (0 = healthy ; 1 = dead, open ; 2 = dead, shorted)
  float v[3];			// Actual value of source, in Volts
  //    v[0] healthy
  //    v[1] typically 0.01 Volts when dead and failed open
  //    v[2] typically 0.00 Volts when dead and failed shorted
  float alt[10];		// Array of alternate nominal voltage values, each in Volts
  float selected;		// Selected value of source, in Volts
  float r[3];			// Internal (series) resistance
  //    r[0] typically V / I_max when healthy
  //    r[1] typically 9e8 Ohms when dead and failed open
  //    r[2] typically 1e-1 Ohm when dead and failed shorted
  float tolerance;		// Voltage tolerance, in +/- percent
} dcv[COUNT];

//--------------------------------------------------------------------------

struct dc_i_source		// Array of DC current sources for circuit
{
  int h;			// Health status of source (0 = healthy ; 1 = dead, open ; 2 = dead, shorted)
  float i[3];			// Actual value of source, in Amperes
  //    i[0] healthy
  //    i[1] typically 1e-12 Amperes when dead and failed open
  //    i[2] typically 1e-10 Amperes when dead and failed shorted
  float alt[10];		// Array of alternate nominal current values, each in Amperes
  float selected;		// Selected value of source, in Amperes
  float r[3];			// Internal (parallel) resistance 
  //    r[0] typically V_max / I when healthy
  //    r[1] typically 9e8 Ohms when dead and failed open
  //    r[2] typically 1e-1 Ohm when dead and failed shorted
  float tolerance;		// Current tolerance, in +/- percent
} dci[COUNT];

//--------------------------------------------------------------------------

struct resistor			// Array of resistors for circuit
{
  int h;			// Health status of resistor (0 = healthy ; 1 = failed open ; 2 = failed shorted)
  float r[3];			// Actual value of resistor, in Ohms
  //    r[0] set equal to selected when healthy
  //    r[1] typically 9e8 Ohms when failed open
  //    r[2] typically 1e-2 Ohm when failed shorted
  float alt[10];		// Array of alternate resistance values, each in Ohms
  float selected;		// Selected value of resistor, in Ohms
  float tolerance;		// Resistance tolerance, in +/- percent
} r[COUNT];

//--------------------------------------------------------------------------

struct potentiometer		// Array of pots for circuit
{
  int h;			// Health status of pot (0 = healthy ; 1 = open 0% term ; 
  //                       2 = open 100% term ; 3 = open wiper)
  float x;			// Per-unit position of pot shaft (0.0 to 1.0, inclusive)
  float r_total;		// Total end-to-end resistance of pot, in Ohms
  float r0[4];			// Actual resistance from wiper to 0% terminal, in Ohms
  //    r0[0] set equal to r_total * x when healthy
  //    r0[1] typically 9e8 Ohms when 0% terminal failed open
  //    r0[2] equal to r0[0] when 100% terminal failed open 
  //    r0[3] equal to r0[0] when wiper failed open 
  float r100[4];		// Actual resistance from wiper to 100% terminal, in Ohms
  //    r100[0] set equal to r_total * (1 - x) when healthy
  //    r100[1] equal to r100[0] when 0% terminal failed open 
  //    r100[2] typically 9e8 Ohms when 100% terminal failed open
  //    r100[3] equal to r100[0] when wiper failed open 
  float r_wiper[4];		// Actual resistance from wiper to track contact, in Ohms
  //    r_wiper[0] set equal to 1e-2 when healthy
  //    r_wiper[1] typically 1e-2 Ohms when 0% terminal failed open 
  //    r_wiper[2] typically 1e-2 Ohms when 100% terminal failed open
  //    r_wiper[3] typically 9e8 Ohms when wiper failed open 
  float alt[10];		// Array of alternate end-to-end resistance values, each in Ohms
  float selected;		// Selected end-to-end resistance value of pot, in Ohms
  float tolerance;		// End-to-end resistance tolerance, in +/- percent
} pot[COUNT];

//--------------------------------------------------------------------------

struct fuse			// Array of fuses for circuit
{
  int h;			// Health status of fuse (0 = healthy ; 1 = blown open)
  float r[2];			// End-to-end resistance of fuse
  //    r[0] typically 1e-1 Ohm when healthy
  //    r[1] typically 9e9 Ohms when blown open
  float imax;			// Maximum current, in Amperes
} f[COUNT];

//--------------------------------------------------------------------------

struct toggle_switch		// Array of toggle switches for circuit
{
  int s;			// Intended state of switch (0 = open ; 1 = closed)
  int h;			// Health status of switch (0 = healthy ; 1 = failed open ; 2 = failed shorted)
  float r[2][3];		// Contact-to-contact resistance of switch 
  //    r[0][0] typically 9e8 Ohms when open and healthy
  //    r[1][0] typically 1e-2 Ohm +/- 5e-3 Ohms (randomized with each closure) when closed and healthy
  //    r[0][1] typically 9e8 Ohms when open and failed open
  //    r[1][1] typically 9e8 Ohms when closed but failed open
  //    r[0][2] typically 1e-1 Ohm when open but failed shorted
  //    r[1][2] typically 1e-1 Ohm when closed and failed shorted
} s[COUNT];

//--------------------------------------------------------------------------

struct relay_contact		// Array of relay contacts for circuit
{
  int s;			// Intended state of contact (0 = open ; 1 = closed)
  int h;			// Health status of contact (0 = healthy ; 1 = failed open ; 2 = failed shorted)
  float r[2][3];		// End-to-end resistance of relay contacts
  //    r[0][0] typically 9e8 Ohms when open state and healthy
  //    r[1][0] typically 1e-2 Ohm +/- 5e-3 Ohms (randomized with each closure) when closed state and healthy
  //    r[0][1] typically 9e8 Ohms when open state and contact failed open
  //    r[1][1] typically 9e8 Ohms when closed state but contact failed open
  //    r[0][2] typically 1e-1 Ohm when open state but contact failed shorted
  //    r[1][2] typically 1e-1 Ohm when closed state and failed shorted
} rc[COUNT];

//--------------------------------------------------------------------------

struct wire			// Array of permanent wires for circuit
{
  int h;			// Health status of wire (0 = healthy ; 1 = failed open)
  float r[2];			// End-to-end resistance of permanent wire
  //    r[0] typically 1 Ohm when healthy
  //    r[1] typically 9e8 Ohms when failed open
} w[COUNT];


//--------------------------------------------------------------------------

struct jumper			// Array of temporary "jumper" wires for circuit
{
  int s;			// Installation state of jumper (0 = uninstalled ; 1 = connected)
  float r[2];			// End-to-end resistance of jumper wire
  //    r[0] typically 9e9 Ohms when uninstalled
  //    r[1] typically 1e-1 Ohm when connected
  int jtp[2];			// Jumper test points [0] and [1]
} j[COUNT];

//--------------------------------------------------------------------------

struct generic_load		// Array of generic loads for circuit
{
  int s;			// Energization state of load (0 = de-energized ; 1 = energized)
  int h;			// Health status of load (0 = healthy ; 1 = failed open ; 2 = failed shorted)
  char *d;			// Text string containing a description of the load
  float r[3];			// Actual resistance value of load, in Ohms
  //    r[0] load resistance when healthy
  //    r[1] typically 9e8 Ohms when failed open
  //    r[2] typically 1e-2 Ohm when failed shorted
  float v;			// Terminal voltage of load
  float i;			// Terminal current of load
  float v_min;			// Minimum voltage for energization
  float i_min;			// Minimum current for energization
} ld[COUNT];

//--------------------------------------------------------------------------

struct capacitor		// Array of capacitors for circuit
{
  int h;			// Health status of capacitor (0 = healthy ; 1 = failed open ; 2 = failed shorted)
  float c;			// Actual value of capacitor, in Farads
  float alt[10];		// Array of alternate nominal capacitance values, each in Farads
  float selected;		// Selected value of capacitor, in Farads
  float tolerance;		// Capacitance tolerance, in +/- percent
  float esr[3];			// Equivalent Series Resistance of capacitor, in Ohms
  //    esr[0] typically 1 Ohm when healthy
  //    esr[1] typically 9e8 Ohms when failed open
  //    esr[2] typically 1e-2 Ohm when failed shorted
  float epr[3];			// Equivalent Parallel Resistance of capacitor, in Ohms
  //    epr[0] typically 9e5 Ohms
  //    epr[1] typically 9e8 Ohms
  //    epr[2] typically 1e-2 Ohm
} c[COUNT];

//--------------------------------------------------------------------------
