/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 000] -- simple one-resistor circuit with DC voltage source

   One electric heating element (2 watts) powered through two multi-
   segment wires by a DC voltage source, protected by a single fuse


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

int init_000 (void);
int fault_000 (void);
int sim_000 (void);

int
circuit_000 (void)
{
  clear_screen ();

  init_000 ();			// Initialize component values
  fault_000 ();			// Randomly choose a fault
  sim_000 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_000 ();

      clear_screen ();

    }

  return 0;
}




int
init_000 (void)
{

  int n;

  tp = 9;			// 9 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 1;
  r[0].h = 1;			// Representing the heating element with a resistor
  w[0].h = 7;
  f[0].h = 1;

  dcv[1].tolerance = random_component (5.0, 75.0);	// Randomly sets the source's tolerance between +/-1.25% and +/-8.75%
  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance);	// Setting actual DC source voltage 

  f[1].imax = 1.0;		// Maximum fuse current set to 1.0 Ampere

  r[1].tolerance = random_component (10.0, 90.0);	// Randomly sets the resistor's tolerance between +/-1% and +/-19%
  r[1].selected = pow (dcv[1].selected, 2) / 2;	// Selecting heater resistance based on the DC voltage
  // source nominal value and the heater's 2-watt rating
  r[1].r[0] = random_component (r[1].selected, r[1].tolerance);	// Setting actual heater resistance value

  for (n = 1; n <= 7; ++n)	// Randomizing wire resistance values 
    {
      w[n].r[0] = random_component (0.05, 50);	// 0.05 Ohm +/- 50%  (i.e. 0.025 Ohm to 0.075 Ohms)
    }

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 8;			// Voltmeter red lead on test point 8
  vm_black = 9;			// Voltmeter black lead on test point 9
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.01;			// Meter noise = +/- 0.01%

  return 0;
}




int
fault_000 (void)
{
  int n;
  int max = 10;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Wire W1 failed open";
  faults[2] = "Wire W2 failed open";
  faults[3] = "Wire W3 failed open";
  faults[4] = "Wire W4 failed open";
  faults[5] = "Wire W5 failed open";
  faults[6] = "Wire W6 failed open";
  faults[7] = "Wire W7 failed open";
  faults[8] = "Dead source";
  faults[9] = "Fuse open (blown)";
  faults[10] = "Heater (R1) failed open";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_000.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("toggling switches and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf ("connected between test points TP%i and TP%i. \n \n",
	  vm_red, vm_black);

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 10;                 // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 2;
  par_cost = 5;
  par_time = 60;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Wire W1 failed open
      w[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 2:			// Wire W2 failed open
      w[2].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 3:			// Wire W3 failed open
      w[3].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 4:			// Wire W4 failed open
      w[4].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 5:			// Wire W5 failed open
      w[5].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 6:			// Wire W6 failed open
      w[6].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 7:			// Wire W7 failed open
      w[7].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 8:			// Source V1 dead, open
      dcv[1].h = 1;
      par_steps = 5;
      par_cost = 8;
      break;

    case 9:			// Fuse blown
      f[1].h = 1;
      par_steps = 6;
      par_cost = 10;
      break;

    case 10:			// Heater (resistor R1) failed open
      r[1].h = 1;
      par_steps = 3;
      par_cost = 7;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_000 (void)
{
  int n, m;

  // Declare shorthand variables
  float r_total, r1, r_fuse;
  float wire[8];
  float i_src, v_src;

  // Initialize shorthand variables
  for (n = 1; n <= 7; ++n)
    wire[n] = w[n].r[w[n].h];

  r1 = r[1].r[r[1].h];

  r_fuse = f[1].r[f[1].h];

  v_src = dcv[1].v[dcv[1].h];

  // Calculating total circuit resistance
  r_total =
    r_fuse + wire[1] + wire[2] + wire[3] + wire[4] + wire[5] + wire[6] +
    wire[7] + r1;

  // Calculate source current using Ohm's Law
  i_src = v_src / r_total;

  // Set all test point currents to the total current value
  for (n = 0; n <= tp; ++n)
    i_tp[n] = i_src;

  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[1][0] = v_src;
  v_tp[2][0] = v_src - (i_src * r_fuse);
  v_tp[4][0] = v_src - (i_src * (r_fuse + wire[2]));
  v_tp[6][0] = v_src - (i_src * (r_fuse + wire[2] + wire[4]));
  v_tp[8][0] = v_src - (i_src * (r_fuse + wire[2] + wire[4] + wire[6]));
  v_tp[3][0] = i_src * wire[1];
  v_tp[5][0] = i_src * (wire[1] + wire[3]);
  v_tp[7][0] = i_src * (wire[1] + wire[3] + wire[5]);
  v_tp[9][0] = i_src * (wire[1] + wire[3] + wire[5] + wire[7]);

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }

  return 0;
}
