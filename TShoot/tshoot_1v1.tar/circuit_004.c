/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 004] -- two-load loaded voltage divider with DC voltage source

   Two load resistors powered from a three-resistor voltage divider
   network, which receives power from a DC voltage source through a single
   fuse.


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

int init_004 (void);
int fault_004 (void);
int sim_004 (void);

int
circuit_004 (void)
{
  clear_screen ();

  init_004 ();			// Initialize component values
  fault_004 ();			// Randomly choose a fault
  sim_004 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_004 ();

      clear_screen ();

    }

  return 0;
}




int
init_004 (void)
{

  int n;

  tp = 6;			// 6 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 1;
  r[0].h = 5;
  s[0].h = 2;
  f[0].h = 1;

  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
//  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance); // Setting actual DC source voltage 
  dcv[1].v[0] = dcv[1].selected;

  f[1].imax = 0.1;		// Maximum fuse current set to 0.1 Ampere

  // Randomizing divider resistor values (R3 through R5),
  // choosing among the lower-resistance alternatives
  for (n = 3; n <= 5; ++n)
    {
      r[n].selected = r[n].alt[random_whole (2)];
      r[n].r[0] = random_component (r[n].selected, r[n].tolerance);
    }

  // Randomizing load resistor values (R1 and R2),
  // choosing among the higher-resistance alternatives
  for (n = 1; n <= 2; ++n)
    {
      r[n].selected = r[n].alt[6 + random_whole (3)];
      r[n].r[0] = random_component (r[n].selected, r[n].tolerance);
    }

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 6;			// Voltmeter red lead on test point 6
  vm_black = 0;			// Voltmeter black lead on test point 0
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.05;			// Meter noise = +/- 0.05%
//  noise = 0.0;                        // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR ZERO NOISE!

  return 0;
}




int
fault_004 (void)
{
  int n;
  int max = 16;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Dead source";
  faults[2] = "Fuse open (blown)";
  faults[3] = "Switch S1 failed open";
  faults[4] = "Switch S1 failed shorted";
  faults[5] = "Switch S2 failed open";
  faults[6] = "Switch S2 failed shorted";
  faults[7] = "Resistor R1 (Load 1) failed open";
  faults[8] = "Resistor R1 (Load 1) failed shorted";
  faults[9] = "Resistor R2 (Load 2) failed open";
  faults[10] = "Resistor R2 (Load 2) failed shorted";
  faults[11] = "Resistor R3 failed open";
  faults[12] = "Resistor R3 failed shorted";
  faults[13] = "Resistor R4 failed open";
  faults[14] = "Resistor R4 failed shorted";
  faults[15] = "Resistor R5 failed open";
  faults[16] = "Resistor R5 failed shorted";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_004.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("toggling switches and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf ("connected between test points TP%i and TP%i and both switches \n",
	  vm_red, vm_black);
  printf ("in their `off' states. \n \n");

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 16;                 // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 5;
  par_cost = 10;
  par_time = 120;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Source V1 dead, open
      dcv[1].h = 1;
      par_steps = 4;
      par_cost = 5;
      break;

    case 2:			// Fuse blown
      f[1].h = 1;
      par_steps = 5;
      par_cost = 10;
      break;

    case 3:			// Switch S1 failed open
      s[1].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 4:			// Switch S1 failed shorted
      s[1].h = 2;
      par_steps = 1;
      par_cost = 1;
      break;

    case 5:			// Switch S2 failed open
      s[2].h = 1;
      par_steps = 6;
      par_cost = 8;
      break;

    case 6:			// Switch S2 failed shorted
      s[2].h = 2;
      par_steps = 5;
      par_cost = 6;
      break;

    case 7:			// Resistor R1 (Load 1) failed open
      r[1].h = 1;
      par_steps = 6;
      par_cost = 7;
      break;

    case 8:			// Resistor R1 (Load 1) failed shorted
      r[1].h = 2;
      par_steps = 8;
      par_cost = 10;
      break;

    case 9:			// Resistor R2 (Load 2) failed open
      r[2].h = 1;
      par_steps = 7;
      par_cost = 8;
      break;

    case 10:			// Resistor R2 (Load 2) failed shorted
      r[2].h = 2;
      par_steps = 4;
      par_cost = 4;
      break;

    case 11:			// Resistor R3 failed open
      r[3].h = 1;
      par_steps = 6;
      par_cost = 9;
      break;

    case 12:			// Resistor R3 failed shorted
      r[3].h = 2;
      par_steps = 4;
      par_cost = 5;
      break;

    case 13:			// Resistor R4 failed open
      r[4].h = 1;
      par_steps = 7;
      par_cost = 11;
      break;

    case 14:			// Resistor R4 failed shorted
      r[4].h = 2;
      par_steps = 6;
      par_cost = 7;
      break;

    case 15:			// Resistor R5 failed open
      r[5].h = 1;
      par_steps = 6;
      par_cost = 13;
      break;

    case 16:			// Resistor R5 failed shorted
      r[5].h = 2;
      par_steps = 7;
      par_cost = 14;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_004 (void)
{
  int n, m;

  // Here we call the update_pots() function to update the resistance
  // value for each portion of each potentiometer, based on total
  // resistance (r_total) and wiper position (x).
  update_pots ();

  // Declare shorthand variables
  float r_total;
  float r1, r2, r3, r4, r5;
  float r_load1_net, r_load2_net;
  float v_load1_net, v_load2_net;
  float i_load1, i_load2;
  float r_switch1, r_switch2;
  float r_fuse;
  float i_src, v_src;


  // Initialize shorthand variables
  r1 = r[1].r[r[1].h];
  r2 = r[2].r[r[2].h];
  r3 = r[3].r[r[3].h];
  r4 = r[4].r[r[4].h];
  r5 = r[5].r[r[5].h];
  r_fuse = f[1].r[f[1].h];
  r_switch1 = s[1].r[s[1].s][s[1].h];
  r_switch2 = s[2].r[s[2].s][s[2].h];
  v_src = dcv[1].v[dcv[1].h];

  // Begin circuit analysis
  // Note: load1_net is the parallel network of R5 // (r_switch1 -- r1)
  // Note: load2_net is the parallel network of (r_load1_net -- R4) // (r_switch2 -- r2)
  //   which is the combination of all resistances except for R3 and Rfuse
  r_load1_net = 1 / ((1 / r5) + (1 / (r1 + r_switch1)));
  r_load2_net = 1 / ((1 / (r4 + r_load1_net)) + (1 / (r2 + r_switch2)));
  r_total = r_fuse + r3 + r_load2_net;

  // Calculate total (source) current using Ohm's Law
  i_src = v_src / r_total;

  // Set test point currents equal to the total current value
  i_tp[0] = i_src;
  i_tp[1] = i_src;
  i_tp[2] = i_src;

  // Calculate voltage across the load 2 subnetwork (all resistances other than R3 and Rfuse)
  v_load2_net = i_src * r_load2_net;

  // Calculate load 2's current and set test points 3 and 4 currents equal to this
  i_load2 = v_load2_net / (r_switch2 + r2);
  i_tp[3] = i_load2;
  i_tp[4] = i_load2;

  // Calculate voltage across the load 1 subnetwork (R5, switch1, R1)
  v_load1_net = (i_src - i_load2) * r_load1_net;

  // Calculate load 1's current and set test points 5 and 6 currents equal to this
  i_load1 = v_load1_net / (r_switch1 + r1);
  i_tp[5] = i_load1;
  i_tp[6] = i_load1;

  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[1][0] = v_src;
  v_tp[2][0] = v_src - (i_src * r_fuse);
  v_tp[3][0] = v_load2_net;
  v_tp[4][0] = i_load2 * r2;
  v_tp[5][0] = v_load1_net;
  v_tp[6][0] = i_load1 * r1;

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }

  // Forcing test point-pair voltages for all combinations
  // of two series opens (i.e. when both the switch and one
  // other component are failed open).  This assumes only
  // one actual *fault* in the circuit at any time.
  if (r_switch1 > 1e6 && r1 > 1e6)	// Switch 1 and R1 both open leaving TP6 floating
    {
      force_voltage (6, 0, 0.0);
      force_voltage (6, 1, 0.0);
      force_voltage (6, 2, 0.0);
      force_voltage (6, 3, 0.0);
      force_voltage (6, 4, 0.0);
      force_voltage (6, 5, 0.0);
    }

  if (r_switch2 > 1e6 && r2 > 1e6)	// Switch 2 and R2 both open leaving TP4 floating
    {
      force_voltage (4, 0, 0.0);
      force_voltage (4, 1, 0.0);
      force_voltage (4, 2, 0.0);
      force_voltage (4, 3, 0.0);
      force_voltage (4, 5, 0.0);
      force_voltage (4, 6, 0.0);
    }

  return 0;
}
