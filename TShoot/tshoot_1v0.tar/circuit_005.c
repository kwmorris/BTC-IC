/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 2 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA


   [Circuit 005] -- adjustable Wheatstone bridge with DC voltage source

   One potentiometer and three fixed resistors in a Wheatstone bridge
   network, receiving power from a DC voltage source through a single
   fuse.


*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>

int init_005 (void);
int fault_005 (void);
int sim_005 (void);

int
circuit_005 (void)
{
  clear_screen ();

  init_005 ();			// Initialize component values
  fault_005 ();			// Randomly choose a fault
  sim_005 ();			// Simulate circuit

  // Get the current UNIX system time as the timestamp that the user
  // began troubleshooting
  steplog[0].time = (int) (time (NULL));

  while (mistake == 0 && conclusion == -1)	// Loop runs until a mistake or conclusion is made
    {
      print_components (1);	// 1 = Print component nominal values and switch/jumper statuses

      print_measurements ();

      user_test ();

      sim_005 ();

      clear_screen ();

    }

  return 0;
}




int
init_005 (void)
{

  tp = 4;			// 6 test points in circuit in addition to TP 0

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components will
  // be in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  For jumpers we use the "status"
  // element (i.e. j[0].s).
  //
  // Following the "blank_slate()" function, all health and status values
  // should be set to zero, so all we must do here is specify components 
  // that are in the circuit (i.e. we don't have to declare what IS NOT in 
  // the circuit, but only what IS).
  dcv[0].h = 1;
  r[0].h = 3;
  pot[0].h = 1;
  f[0].h = 1;

  dcv[1].selected = dcv[1].alt[random_whole (9)];	// Randomly selecting nominal source voltage value
//  dcv[1].v[0] = random_component (dcv[1].selected, dcv[1].tolerance); // Setting actual DC source voltage 
  dcv[1].v[0] = dcv[1].selected;

  f[1].imax = 0.1;		// Maximum fuse current set to 0.1 Ampere

  // Choosing one random resistance value for both
  // resistors R2 and R3, to ensure the bridge is
  // symmetrical
  r[2].selected = r[2].alt[random_whole (9)];
  r[3].selected = r[2].selected;
  r[2].r[0] = random_component (r[2].selected, r[2].tolerance);
  r[3].r[0] = random_component (r[3].selected, r[3].tolerance);

  // Choosing one random resistance value for 
  // resistor R1, then ensuring R_pot can achieve 
  // that value by re-randomizing the pot's
  // selected value until it is greater than 
  // 1.5 times r1 and less than 4 times r1
  r[1].selected = r[1].alt[random_whole (9)];
  while (pot[1].selected <= (r[1].selected * 1.5)
	 || pot[1].selected >= (r[1].selected * 3.0))
    {
      pot[1].selected = pot[1].alt[random_whole (9)];
    }
  r[1].r[0] = random_component (r[1].selected, r[1].tolerance);
  pot[1].r_total = random_component (pot[1].selected, pot[1].tolerance);

  // Jumper wires ready to connect between pre-defined test points
  // j[1].jtp[0] = 3;
  // j[1].jtp[1] = 4;
  // j[2].jtp[0] = 2;
  // j[2].jtp[1] = 5;

  vm_red = 3;			// Voltmeter red lead on test point 3
  vm_black = 4;			// Voltmeter black lead on test point 4
  vm_cost = 2;			// Voltmeter costs $2 to move test leads

  am_cost = 5;			// Ammeter costs $5 to move 

  j_cost = 10;			// Inserting a temporary jumper wire costs $10

  noise = 0.05;			// Meter noise = +/- 0.05%
//  noise = 0.0;                        // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, FOR ZERO NOISE!

  return 0;
}




int
fault_005 (void)
{
  int n;
  int max = 9;			// Number of possible faults (excluding 0 = No fault)

  // Initialize fault array
  faults[0] = "No fault";
  faults[1] = "Dead source";
  faults[2] = "Fuse open (blown)";
  faults[3] = "Resistor R1 failed open";
  faults[4] = "Resistor R1 failed shorted";
  faults[5] = "Resistor R2 failed open";
  faults[6] = "Resistor R2 failed shorted";
  faults[7] = "Resistor R3 failed open";
  faults[8] = "Resistor R3 failed shorted";
  faults[9] = "Potentiometer failed open";

  printf
    ("If you haven't already, please open the schematic diagram file \n");
  printf ("`circuit_005.pdf' for reference while troubleshooting \n \n");

  printf
    ("The computer will now randomly select one condition from the following list: \n \n");

  for (n = 0; n <= max; ++n)
    printf ("Condition (%i) = %s \n", n, faults[n]);

  printf
    ("\nYour task will be to determine which one of these conditions exists \n");
  printf
    ("based on virtual tests you will perform on the circuit such as \n");
  printf
    ("adjusting potentiometers and placing meters at various test points. \n \n");

  printf ("The troubleshooting scenario will begin with the voltmeter \n");
  printf ("connected between test points TP%i and TP%i and potentiometer \n",
	  vm_red, vm_black);
  printf ("Pot 1 set to its 50 percent position. \n \n");

  printf ("Please type your name (no spaces, 40 characters maximum) \n");
  printf ("and press the <Enter> key to continue \n");

  scanf ("%40s", username);

  // Discard characters from stdin buffer until a linefeed (LF, or ASCII code 10)
  // is detected.
  while (getchar () != 10)
    {
      // Does nothing!
    }

  clear_screen ();

  fault = random_whole (max);

//  fault = 2;                  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO FORCE A KNOWN FAULT!

  // Default "par" scores
  par_steps = 2;
  par_cost = 4;
  par_time = 120;		// 60 seconds = 1 minute

  switch (fault)
    {
    case 1:			// Source V1 dead, open
      dcv[1].h = 1;
      par_steps = 3;
      par_cost = 5;
      break;

    case 2:			// Fuse blown
      f[1].h = 1;
      par_steps = 4;
      par_cost = 6;
      break;

    case 3:			// Resistor R1 failed open
      r[1].h = 1;
      par_steps = 4;
      par_cost = 8;
      break;

    case 4:			// Resistor R1 failed shorted
      r[1].h = 2;
      par_steps = 4;
      par_cost = 8;
      break;

    case 5:			// Resistor R2 failed open
      r[2].h = 1;
      par_steps = 4;
      par_cost = 8;
      break;

    case 6:			// Resistor R2 failed shorted
      r[2].h = 2;
      par_steps = 4;
      par_cost = 8;
      break;

    case 7:			// Resistor R3 failed open
      r[3].h = 1;
      par_steps = 4;
      par_cost = 8;
      break;

    case 8:			// Resistor R3 failed shorted
      r[3].h = 2;
      par_steps = 4;
      par_cost = 8;
      break;

    case 9:			// Potentiometer failed open
      pot[1].h = 1;
      par_steps = 4;
      par_cost = 8;
      break;
    }

  // Calculating "limits" for steps taken, testing budget, and time
  limit_steps = 4 * par_steps;
  limit_cost = 4 * par_cost;
  limit_time = 4 * par_time;

//  limit_steps = 9999;  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_cost = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!
//  limit_time = 9999;   // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO AVOID FAILING!

  return 0;
}





int
sim_005 (void)
{
  int n, m;

  // Here we call the update_pots() function to update the resistance
  // value for each portion of each potentiometer, based on total
  // resistance (r_total) and wiper position (x).
  update_pots ();

  // Declare shorthand variables
  float r_total;
  float r1, r2, r3;
  float r_fuse, r_pot, r_bridge;
  float v_bridge, i_left, i_right;
  float i_src, v_src;

  // Initialize shorthand variables
  r1 = r[1].r[r[1].h];
  r2 = r[2].r[r[2].h];
  r3 = r[3].r[r[3].h];
  r_fuse = f[1].r[f[1].h];
  r_pot = pot[1].r0[pot[1].h];
  v_src = dcv[1].v[dcv[1].h];

  // Begin circuit analysis
  r_bridge = 1 / ((1 / (r1 + r2)) + (1 / (r_pot + r3)));
  r_total = r_fuse + r_bridge;

  // Calculate total (source) current using Ohm's Law
  i_src = v_src / r_total;

  if (i_src > f[1].imax)	// Check to see if current will blow fuse
    {
      f[1].h = 1;
      mistake = 1;
    }

  // Set test points TP0-TP2 current values equal to the total current value
  i_tp[0] = i_src;
  i_tp[1] = i_src;
  i_tp[2] = i_src;

  // Set test points TP3 and TP4 current values to zero
  i_tp[3] = 0.0;
  i_tp[4] = 0.0;

  // Calculate voltage across vertical span of bridge network
  v_bridge = i_src * r_bridge;

  // Calculate currents through each parallel branch of the bridge
  i_left = v_bridge / (r1 + r2);
  i_right = v_bridge / (r_pot + r3);

  // Calculate all test point voltages with respect to ground (TP 0)
  v_tp[0][0] = 0.0;		// TP 0 (ground) is 0 Volts by definition . . .
  v_tp[1][0] = v_src;
  v_tp[2][0] = v_src - (i_src * r_fuse);
  v_tp[3][0] = i_left * r2;
  v_tp[4][0] = i_right * r3;

  // Calculate all test point-pair voltages
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = v_tp[n][0] - v_tp[m][0];
    }

  return 0;
}
