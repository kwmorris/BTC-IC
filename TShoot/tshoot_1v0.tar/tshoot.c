/*************************************************************************
TROUBLESHOOT -- Circuit troubleshooting simulator program
By Tony R. Kuphaldt
Copyright (C) 2018
Last update 4 October 2018

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your 
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this software; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

*************************************************************************/

#include "tshoot.h"		// Contains all the declarations specific to tshoot
#include <stdio.h>
#include <stdlib.h>		// Necessary for the "random" function to work
#include <time.h>		// Necessary for the "time" library functions to work
#include <math.h>


int
main (void)
{

  int n;

  clear_screen ();

  // Initialize all global variables for a new simulation
  blank_slate ();

  printf
    ("Welcome to TROUBLESHOOT version 1.0, the circuit-troubleshooting \n");
  printf ("game that helps prepare you for a technical career! \n");

  printf ("\n");

  printf ("Copyright (C) 2018 Tony R. Kuphaldt \n");
  printf ("This program comes with ABSOLUTELY NO WARRANTY! \n");
  printf ("This is free software, and you are welcome to distribute it \n");
  printf
    ("under certain conditions; view the file `GPL_v3.txt' for details. \n");

  printf ("\n");

  printf ("Schematic diagrams for each circuit are provided in  \n");
  printf ("both Adobe PDF and Adobe PostScript formats for you  \n");
  printf ("to view in a separate application when running this  \n");
  printf ("program.  \n");

  printf ("\n \n");

  printf ("Choose a circuit to troubleshoot: \n\n");

  printf
    ("(0) Simple one-resistor circuit with DC voltage source ------- (`circuit_000') \n");

  printf
    ("(1) Three-resistor voltage divider with DC voltage source ---- (`circuit_001') \n");

  printf
    ("(2) Three-resistor current divider with DC current source ---- (`circuit_002') \n");

  printf
    ("(3) Four-wire resistive sensor with DC current source -------- (`circuit_003') \n");

  printf
    ("(4) Two-load loaded voltage divider with DC voltage source --- (`circuit_004') \n");

  printf
    ("(5) Adjustable Wheatstone bridge with DC voltage source ------ (`circuit_005') \n");

  printf
    ("(6) 4-20 mA loop-powered transmitter circuit ----------------- (`circuit_006') \n");

  printf
    ("(7) 4-20 mA externally-powered transmitter circuit ----------- (`circuit_007') \n");

  printf
    ("(8) Relay-controlled motor circuit --------------------------- (`circuit_008') \n");

  printf ("\nPlease type your selection number and press <Enter>:");
  scanf ("%i", &n);

  // "Seed" the random number generator with the UNIX system time
  // plus the user's selection, just for good measure!
  srandom ((int) (time (NULL)) + n);

  switch (n)
    {
    case 0:
      circuit_000 ();
      break;

    case 1:
      circuit_001 ();
      break;

    case 2:
      circuit_002 ();
      break;

    case 3:
      circuit_003 ();
      break;

    case 4:
      circuit_004 ();
      break;

    case 5:
      circuit_005 ();
      break;

    case 6:
      circuit_006 ();
      break;

    case 7:
      circuit_007 ();
      break;

    case 8:
      circuit_008 ();
      break;
    }

  debrief ();

  return 0;
}













int
random_whole (int max)
{

  float y;
  float x;

  y = (float) (random ());	// Casts the random long integer as a floating-point value
  x = (float) RAND_MAX;		// Casts the RAND_MAX (long integer) as a floating-point value

  // This function returns a whole-number value ranging from 0 to "max", inclusive
  return (int) ((max + 1) * y / x);

}



float
random_component (float nominal, float percent)
{

  // "nominal" is the component value with no error whatsoever (i.e. +/-0% tolerance)
  // "percent" is the maximum deviation (+ or -) from the center value in %

  float y;
  float x;
  float deviation;

  y = (float) (random ());	// Casts the random long integer as a floating-point value
  x = (float) RAND_MAX;		// Casts the RAND_MAX (long integer) as a floating-point value

  deviation = nominal * percent / 100.0;	// Calculating deviation from nominal value

  // Note: y / x will be equal to a random number between 0.000 and 1.000 inclusive
  // This function returns a floating-point value equal to nominal +/- deviation%
  return nominal + ((2 * deviation * y / x) - deviation);

}






int
clear_screen (void)
{
  int n;

  // Crude screen-clearing routine
  for (n = 0; n < 50; ++n)
    {
      printf ("\n");
    }

  return 0;
}







int
force_voltage (int red, int black, float x)
{

  // The purpose of this function is to force voltage
  // measurements to specific values such as zero or
  // full supply voltage in the case of anomalous 
  // conditions such as two opens in a series network.

  v_tp[red][black] = x;
  v_tp[black][red] = -x;

  return 0;
}








int
force_all_voltages (float x)
{
  int n, m;

  // The purpose of this function is to force all 
  // voltage measurements to a specific value such
  // as zero in the case of anomalous conditions 
  // such as two opens in a series network.
  for (n = 0; n < COUNT; ++n)
    {
      for (m = 0; m < COUNT; ++m)
	v_tp[n][m] = x;
    }

  return 0;
}








int
toggle_switch (int n)
{

  int c;

  cost = cost + n;

  ++step;

  if (s[0].h > 1)
    {
      printf ("Which switch would you like to toggle? ");

      scanf ("%i", &c);

      // Will not allow user to select switch "0" or below
      if (c < 1)
	c = 1;

      // Will not allow user to select switch "COUNT" or above
      if (c >= COUNT)
	c = COUNT - 1;
    }

  else				// In the event there is only one switch in the circuit!
    c = 1;

  if (s[c].s == 0)
    {
      s[c].s = 1;
      // Randomized healthy closed contact resistance to be 0.01 Ohm +/- 0.005 Ohms
      s[c].r[1][0] = random_component (1e-2, 50);
      steplog[step].d = "Turned `on' switch  S";
    }

  else
    {
      s[c].s = 0;
      steplog[step].d = "Turned `off' switch S";
    }

  steplog[step].code = 'S';
  steplog[step].num = c;
  steplog[step].cost = n;
  steplog[step].time = (int) (time (NULL));

  return 0;
}









int
adjust_potentiometer (int n)
{

  int c;
  float entry;

  cost = cost + n;

  ++step;

  if (pot[0].h > 1)
    {
      printf ("Which potentiometer would you like to adjust? ");

      scanf ("%i", &c);

      // Will not allow user to select switch "0" or below
      if (c < 1)
	c = 1;

      // Will not allow user to select switch "COUNT" or above
      if (c >= COUNT)
	c = COUNT - 1;
    }

  else				// In the event there is only one switch in the circuit!
    c = 1;

  printf ("Enter wiper position, in percent: ");
  scanf ("%f", &entry);

  pot[c].x = entry / 100.0;

  if (pot[c].x < 0.0)
    pot[c].x = 0.0;

  if (pot[c].x > 1.0)
    pot[c].x = 1.0;

  update_pots ();

  steplog[step].code = 'P';
  steplog[step].d = "Adjusted Pot ";
  steplog[step].adjust = pot[c].x * 100.0;
  steplog[step].num = c;
  steplog[step].cost = n;
  steplog[step].time = (int) (time (NULL));

  return 0;

}









int
place_jumper (int n)
{

  int c, count;

  ++step;

  if (j[0].s > 1)
    {
      printf
	("Which jumper would you like to install (enter 0 to remove all)? ");

      scanf ("%i", &c);

      // Will not allow user to select jumper "0" or below
      if (c < 0)
	c = 0;

      // Will not allow user to select jumper "COUNT" or above
      if (c >= COUNT)
	c = COUNT - 1;
    }

  else				// In the event there is only one jumper available!
    c = 1;

  // If user selects "0" it means they wish to remove all jumpers from the circuit
  if (c == 0)
    {
      for (count = 1; count <= j[0].s; ++count)
	j[count].s = 0;
      steplog[step].d = "Removed jumpers";
      steplog[step].cost = 0;
    }

  // Otherwise, install the selected jumper wire
  else
    {
      j[c].s = 1;
      steplog[step].d = "Placed jumper ";
      steplog[step].num = c;
      cost = cost + n;		// Placing jumpers costs $, removing them does not
      steplog[step].cost = n;
      steplog[step].jtp[0] = j[c].jtp[0];
      steplog[step].jtp[1] = j[c].jtp[1];
    }

  steplog[step].code = 'J';
  steplog[step].time = (int) (time (NULL));

  return 0;
}







int
move_voltmeter (int n)
{

  cost = cost + n;

  ++step;

  // "Park" ammeter at test point 0 when taking voltage measurement
  am_tp = 0;

  printf ("Move red lead to TP: ");

  scanf ("%i", &vm_red);

  // Will not allow user to select test point below "0"
  if (vm_red < 0)
    vm_red = 0;

  // Will not allow user to select test point above "tp"
  if (vm_red > tp)
    vm_red = 0;

  printf ("Move black lead to TP: ");

  scanf ("%i", &vm_black);

  // Will not allow user to select test point below "0"
  if (vm_black < 0)
    vm_black = 0;

  // Will not allow user to select test point above "tp"
  if (vm_black > tp)
    vm_black = 0;

  steplog[step].code = 'V';
  steplog[step].d = "Moved voltmeter to TPs ";
  steplog[step].cost = n;
  steplog[step].time = (int) (time (NULL));

  return 0;
}







int
move_ammeter (int n)
{
  cost = cost + n;

  ++step;

  // "Park" voltmeter at test points 0 and 0 when taking current measurement
  vm_red = 0;
  vm_black = 0;

  printf ("Move ammeter to TP: ");

  scanf ("%i", &am_tp);

  // Will not allow user to select test point below "0"
  if (am_tp < 0)
    am_tp = 0;

  // Will not allow user to select test point above "tp"
  if (am_tp > tp)
    am_tp = 0;

  steplog[step].code = 'A';
  steplog[step].d = "Moved ammeter to TP ";
  steplog[step].cost = n;
  steplog[step].time = (int) (time (NULL));

  return 0;
}







int
print_components (int status)
{
  int n;

  // Here we use the "health" integer variable of element 0 for each type
  // of circuit component as a count for how many of these components are
  // in the circuit, since no circuit ever contains a "component 0" 
  // (e.g. resistor R0 or switch S0).  
  printf ("NOMINAL COMPONENT VALUES: \n");

  for (n = 1; n <= dcv[0].h; ++n)
    printf
      ("DC voltage source V%i nominal value = %.0f Volts +/- %.0f percent \n",
       n, dcv[n].selected, dcv[n].tolerance);

  for (n = 1; n <= dci[0].h; ++n)
    printf
      ("DC current source I%i nominal value = %.1f milliAmps +/- %.0f percent \n",
       n, dci[n].selected * 1000, dci[n].tolerance);

  for (n = 1; n <= r[0].h; ++n)
    printf ("Resistor R%i nominal value = %.0f Ohms +/- %.2f percent \n", n,
	    r[n].selected, r[n].tolerance);

  for (n = 1; n <= pot[0].h; ++n)
    printf
      ("Potentiometer Pot%i nominal value = %.0f Ohms +/- %.0f percent \n",
       n, pot[n].selected, pot[n].tolerance);

  for (n = 1; n <= c[0].h; ++n)
    printf
      ("Capacitor C%i nominal value = %.0f microFarads +/- %.0f percent \n",
       n, c[n].selected * 1e6, c[n].tolerance);

  // Show all relevant component statuses
  if (status > 0)
    {
      printf ("STATUSES: \n");

      for (n = 1; n <= s[0].h; ++n)
	{
	  printf ("Switch S%i status = ", n);

	  if (s[n].s == 1)
	    printf ("On \n");
	  else
	    printf ("Off \n");
	}

      for (n = 1; n <= pot[0].h; ++n)
	printf ("Potentiometer Pot%i position = %.1f percent \n", n,
		pot[n].x * 100);

      // For jumpers we use the "status" element (i.e. j[0].s) to determine how 
      // many are in the circuit rather than the "health" element because jumpers
      // cannot fail.
      for (n = 1; n <= j[0].s; ++n)
	printf
	  ("Jumper J%i status = %i (1=installed 0=uninstalled) between TP%i and TP%i \n",
	   n, j[n].s, j[n].jtp[0], j[n].jtp[1]);

      for (n = 1; n <= ld[0].h; ++n)
	{
	  printf ("%s status = ", ld[n].d);

	  if (ld[n].s == 1)
	    printf ("Energized \n");
	  else
	    printf ("De-energized \n");
	}
    }

  // Check for running over maximum limits . . .

  if (step > limit_steps)	// Took too many steps
    mistake = 2;

  if (cost > limit_cost)	// Spent too much money
    mistake = 3;

  if (((int) (time (NULL)) - steplog[0].time) > limit_time)	// Took too much time
    mistake = 4;

  printf ("\n");

  return 0;
}








int
print_measurements (void)
{

  // Eliminates "-0" reading when voltage is zero
  if (v_tp[vm_red][vm_black] == -0.0)
    v_tp[vm_red][vm_black] = 0.0;


  // Include voltmeter test points in steplog
  steplog[step].vtp[0] = vm_red;
  steplog[step].vtp[1] = vm_black;

  // Include ammeter test point in steplog
  steplog[step].atp = am_tp;

  if (vm_red != 0 || vm_black != 0)
    {
      // Add noise to voltmeter reading and include in steplog
      steplog[step].vm = random_component (v_tp[vm_red][vm_black], noise);

      printf
	("Voltmeter measurement = %.3f V ; red on TP %i , black on TP %i \n",
	 steplog[step].vm, vm_red, vm_black);
    }

  if (am_tp != 0)
    {
      // Add noise to ammeter reading and include in steplog
      steplog[step].am = random_component (i_tp[am_tp], noise);

      // Auto-ranging ammeter
      if (steplog[step].am >= 1.0)
	printf ("Ammeter measurement = %.3f A at TP %i \n", steplog[step].am,
		am_tp);

      else
	printf ("Ammeter measurement = %.3f mA at TP %i \n",
		steplog[step].am * 1e3, am_tp);

    }

  printf ("\n");

//  printf ("V1 ACTUAL VOLTAGE = %f Volts \n", dcv[1].v[dcv[1].h]);  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO DISPLAY V1 SOURCE VOLTAGE TO THE USER DURING TROUBLESHOOTING!
//  printf ("FAULT = %i = %s \n", fault, faults[fault]);  // TEMPORARILY UNCOMMENT DURING DEVELOPMENT, TO DISPLAY THE FAULT TO THE USER DURING TROUBLESHOOTING!

  printf ("Steps taken = %i \t", step);
  printf ("Money spent = $%i \t", cost);
  printf ("Time elapsed = %i seconds \n",
	  steplog[step].time - steplog[0].time);

  printf ("\n");

  return 0;
}






int
user_test (void)
{
  char c;

  printf ("What would you like to do? \n");

  if (s[0].h != 0)
    printf ("  [S] Toggle switch ------------ (costs $1)\n");

  if (pot[0].h != 0)
    printf ("  [P] Adjust potentiometer ----- (costs $1)\n");

  if (j[0].s != 0)
    printf ("  [J] Place/remove jumper ------ (costs $%i)\n", j_cost);

  printf ("  [V] Move voltmeter leads ----- (costs $%i) \n", vm_cost);
  printf ("  [A] Move ammeter ------------- (costs $%i) \n", am_cost);
  printf ("  [D] Declare your conclusion -- (free) \n");

  printf ("\n(Press letter key and then press <Enter>)\n");
  scanf ("%c", &c);

  switch (c)
    {
    case 'S':
    case 's':
      if (s[0].h != 0)		// Allows function to be called only if component exists
	toggle_switch (1);
      break;

    case 'P':
    case 'p':
      if (pot[0].h != 0)	// Allows function to be called only if component exists
	adjust_potentiometer (1);
      break;

    case 'J':
    case 'j':
      if (j[0].s != 0)		// Allows function to be called only if component exists
	place_jumper (j_cost);
      break;

    case 'V':
    case 'v':
      move_voltmeter (vm_cost);
      break;

    case 'A':
    case 'a':
      move_ammeter (am_cost);
      break;

    case 'D':
    case 'd':
      declare_fault ();
    }

  return 0;
}




int
update_pots (void)
{
  int n;

  // Here we use the "health" integer variable of pot 0 as a count 
  // for how many pots are in the circuit, since no circuit ever 
  // contains a "pot 0".

  for (n = 1; n <= pot[0].h; ++n)
    {
      pot[n].r0[0] = pot[n].r_total * pot[n].x;	// Actual resistance from wiper to 0% terminal
      pot[n].r0[2] = pot[n].r0[0];	// Wiper-0% terminal resistance assuming open 100% terminal fault
      pot[n].r0[3] = pot[n].r0[0];	// Wiper-0% terminal resistance assuming open wiper fault

      pot[n].r100[0] = pot[n].r_total * (1.0 - pot[n].x);	// Actual resistance from wiper to 100% terminal
      pot[n].r100[1] = pot[n].r100[0];	// Wiper-100% terminal resistance assuming open 0% terminal fault
      pot[n].r100[3] = pot[n].r100[0];	// Wiper-100% terminal resistance assuming open wiper fault
    }

  return 0;
}




int
update_loads (void)
{
  int n;

  // Here we use the "health" integer variable of load 0 as a count 
  // for how many loads are in the circuit, since no circuit ever 
  // contains a "load 0".

  for (n = 1; n <= ld[0].h; ++n)
    {

      // Load is energized of minimum voltage and current values met
      if (ld[n].v > ld[n].v_min && ld[n].i > ld[n].i_min)
	ld[n].s = 1;

      // Otherwise, load is de-energized
      else
	ld[n].s = 0;
    }

  return 0;
}






int
declare_fault (void)
{
  int n;

  ++step;

  printf ("\n");

  for (n = 0; faults[n] != NULL; ++n)
    printf ("Fault (%i) = %s \n", n, faults[n]);

  printf ("\nPlease enter your selection:");
  scanf ("%i", &conclusion);

  steplog[step].code = 'D';
  steplog[step].d = "declared condition";
  steplog[step].time = (int) (time (NULL));

  //printf("\n");
  clear_screen ();

  return 0;
}









int
debrief (void)
{

  int n;

  // Get the current UNIX system time as the timestamp that the user
  // finished troubleshooting
  time_finish = (int) (time (NULL));

  print_components (0);		// 0 = only print component nominal values

//  for (n = 1; n <= step; ++n)
  for (n = 0; n <= step; ++n)
    {

      if (n == 0)
	printf ("As-Found condition ------------------------------------ ");

      if (steplog[n].code == 'S')
	{
	  printf ("Step %2i (+%2i sec) = %s", n,
		  steplog[n].time - steplog[n - 1].time, steplog[n].d);
	  printf ("%i", steplog[n].num);
	  printf (" ------------ ");
	}

      if (steplog[n].code == 'P')
	{
	  printf ("Step %2i (+%2i sec) = %s", n,
		  steplog[n].time - steplog[n - 1].time, steplog[n].d);
	  printf ("%i to %2.1f percent", steplog[n].num, steplog[n].adjust);
	  printf (" ---- ");
	}

      if (steplog[n].code == 'J')
	{
	  printf ("Step %2i (+%2i sec) = %s", n,
		  steplog[n].time - steplog[n - 1].time, steplog[n].d);
	  if (steplog[n].num != 0)
	    {
	      printf ("%i", steplog[n].num);
	      printf (" b/w TPs %i", steplog[n].jtp[0]);
	      printf (" & %i", steplog[n].jtp[1]);
	      printf (" ----- ");
	    }
	  else
	    printf (" ------------------- ");
	}

      if (n == step && mistake == 1)
	printf ("THIS STEP BLEW THE FUSE!");

      if (steplog[n].code == 'V')
	{
	  printf ("Step %2i (+%2i sec) = %s", n,
		  steplog[n].time - steplog[n - 1].time, steplog[n].d);
	  printf ("%2i", steplog[n].vtp[0]);
	  printf (" & %2i", steplog[n].vtp[1]);
	  printf (" ---- ");
	}

      if (steplog[n].code == 'A')
	{
	  printf ("Step %2i (+%2i sec) = %s", n,
		  steplog[n].time - steplog[n - 1].time, steplog[n].d);
	  printf ("%2i", steplog[n].atp);
	  printf (" ------------ ");
	}

      if (steplog[n].code == 'D')
	{
	  printf ("Step %2i (+%2i sec) = ", n,
		  steplog[n].time - steplog[n - 1].time);

	  if (conclusion == fault)
	    printf ("Correctly ");

	  else
	    printf ("Incorrectly ");

	  printf ("%s", steplog[n].d);

	  printf (" to be `%s'", faults[conclusion]);
	}

      // Display meter indications for all steps except declaration of fault
      if (steplog[n].code != 'D')
	{
	  if (steplog[n].vtp[0] != 0 || steplog[n].vtp[1] != 0)
	    printf ("Voltmeter (TP %2i,%2i) = %.3f V", steplog[n].vtp[0],
		    steplog[n].vtp[1], steplog[n].vm);

	  if (steplog[n].atp != 0)
	    printf ("Ammeter   (TP %2i)    = %.3f mA", steplog[n].atp,
		    steplog[n].am * 1000);
	}

      printf ("\n");
    }

  printf ("\n");

  if (conclusion != fault && mistake == 0)
    {
      printf ("I'm sorry, but your selection is not correct. \n");
      printf ("The actual condition was `%s' \n \n", faults[fault]);
    }

  if (mistake == 0)		// User made no mistakes
    {
      printf
	("%s took %i steps in total -------- Par for this scenario is %i steps \n",
	 username, step, par_steps);

      printf
	("%s spent $%i in total ------------ Par for this scenario is $%i \n",
	 username, cost, par_cost);

      printf
	("%s took %i seconds to complete -- Par for this scenario is %i seconds \n",
	 username, time_finish - steplog[0].time, par_time);
    }

  // At the conclusion of this troubleshooting exercise, 
  // display results if any mistakes were made by the user
  //
  if (mistake == 1)		// User blew the fuse
    {
      printf ("\n \n    EPIC FAIL -- YOU BLEW THE FUSE!!! \n \n");
      printf ("The actual condition was `%s' \n \n", faults[fault]);
    }

  if (mistake == 2)		// Took too many steps
    {
      printf
	("\n \n    Sorry, but you took too many steps without declaring a conclusion. \n \n");
      printf ("The actual condition was `%s' \n \n", faults[fault]);
    }

  if (mistake == 3)		// Spent too much money
    {
      printf
	("\n \n    Do you think money grows on trees around here?  You broke the bank. \n \n");
      printf ("The actual condition was `%s' \n \n", faults[fault]);
    }

  if (mistake == 4)		// Took too much time
    {
      printf
	("\n \n    Sorry, but you're taking too much time to diagnose this circuit. \n \n");
      printf ("The actual condition was `%s' \n \n", faults[fault]);
    }

  return 0;
}
